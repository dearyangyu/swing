import maya

maya.stringTable['y_analyticSkinClusters.kAnalyticLabel'] = u'SkinClusters'
maya.stringTable['y_analyticSkinClusters.kAnalyticDescriptionShort'] = u'Analyze type and usage of skin cluster deformers to discover usage patterns contrary to the assumptions of the code.'

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
