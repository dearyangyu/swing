import maya
maya.utils.loadStringResourcesForModule(__name__)

'''
File containing class that handles the UI window for analytics.
Not really meant to be accessed directly, use the utility method
analytic_ui() instead.

    from maya.analytics.Window import analytics_ui
    analytics_ui()

If the environment variable MAYA_ANALYTIC_PATH is set then it will
be read to find the directories where analytics are to be stored
and/or found.

    MAYA_ANALYTIC_PATH="MyFiles;YourFiles"

This will look in the two directories "MyFiles" and "YourFiles" for
files to analyze. If the analytic runs on the current scene then the
first directory in the path will be used to store its results.
'''
#======================================================================
import os
import json
import maya.cmds as cmds
from functools import partial
from maya.common.ui import LayoutManager
from maya.debug.TODO import TODO

from .Logger import Logger
from .Runner import Runner
from .utilities import list_analytics

__all__ = ['AnalyticsWindow', 'analytics_ui']

# Name of the analytic window
ANALYTICS_WINDOW = None

# Sample Runner used by the window to manage options and run analytics
ANALYTICS_RUNNER = Runner()

# Set to True if you want to see debugging output from the UI
DEBUGGING = True

# Different actions to perform using the analytic configuration
RUN_ANALYTICS         = 0
LIST_ANALYTICS        = 1
SHOW_ANALYTIC_COMMAND = 2

# Widget spacing
BUTTON_WIDTH = 60
TEXT_WIDTH   = 150
VSPC         = 10
HSPC         = 10

# Magic number indicating that none of the file paths have been selected
NO_SELECTION = -1

# Modes in the file dialog to choose either a list of files or a directory
FILE_MODE_CREATE = 0
FILE_MODE_FILE = 1
FILE_MODE_FILES = 4
FILE_MODE_DIR = 3

TODO( "FINISH", "Add the ability to save and load analytic window configurations", None )

#======================================================================
# Callbacks
#======================================================================

def debug(msg):
    '''Print the message if debugging is enabled'''
    if DEBUGGING:
        print msg

#======================================================================
def callback_wrapper(*args, **kwargs):
    '''
    This method is a wrapper in the form expected by UI elements.

    Its signature allows it to be flexible with regards to what UI elements
    expects.  Then it simply calls the given functor.
    '''
    kwargs['functor']()

def callback_tool(self, function):
    '''
    This method returns a callback method that can be used by the UI
    elements.

    It wraps the "easier to define" callbacks that only takes the tool as
    an element into the callbacks that UI element expects.
    '''
    functor = partial(function, tool=self)
    return partial(callback_wrapper, functor=functor)

#======================================================================

class PatternWidget(object):
    '''
    Class to manage creation and update of a variable length pattern list widget.

    The list is expanded and contracted dynamically by clicking on the +
    and trash icons rescpectively. Each pattern has a checkbox beside it
    so that it can be skipped without losing track of what the pattern is.

        [X] [  pattern string   ] TRASH
        [X] [  pattern string   ] TRASH
        ADD
    '''

    def __init__(self, parent_widget):
        '''Initialize the widget information'''
        self.pattern_values  = []
        self.enabled_values  = []
        #
        self.__list_widget   = None
        self.__parent_widget = parent_widget
        self.__delete_buttons   = []
        self.__pattern_widgets  = []
        self.__checkbox_widgets = []

    #----------------------------------------------------------------------
    def create_ui(self):
        '''Create the generic text list UI and the buttons that control it'''
        # Clear out the existing list since it will be rebuilt
        if self.__list_widget is not None:
            cmds.deleteUI( self.__list_widget, layout=True )
        self.__list_widget = cmds.rowColumnLayout( parent=self.__parent_widget
                                                 , numberOfColumns=3
                                                 , adjustableColumn=2
                                                 , columnAlign=[(1, 'center'), (2, 'left'), (3, 'left')])
        self.__pattern_widgets    = []
        self.__checkbox_widgets   = []

        checkbox_annotation = maya.stringTable['y_Window.kEnablePatternAnnotation' ]
        pattern_annotation  = maya.stringTable['y_Window.kEnterPatternAnnotation'  ]
        delete_annotation   = maya.stringTable['y_Window.kDeletePatternAnnotation' ]

        with LayoutManager(self.__list_widget):
            if len(self.pattern_values) > 0:
                for data_index in range(len(self.pattern_values)):
                    self.__checkbox_widgets.append( cmds.checkBox( value=self.enabled_values[data_index]
                                             , changeCommand=callback_tool(self, partial(PatternWidget.on_enable, index=data_index))
                                             , label=''
                                             , annotation=checkbox_annotation
                                             )
                                         )
                    self.__pattern_widgets.append( cmds.textField(
                                          text=self.pattern_values[data_index]
                                        , textChangedCommand=callback_tool(self, partial(PatternWidget.on_pattern, index=data_index))
                                        , width=TEXT_WIDTH
                                        , annotation=pattern_annotation
                                        )
                                    )
                    self.__delete_buttons = cmds.symbolButton( image='RS_delete.png'
                                                , command=callback_tool(self, partial(PatternWidget.on_delete, index=data_index))
                                                , annotation=delete_annotation
                                                )
            else:
                # Add padding in for the extra columns in the widget
                cmds.text( label='' )
                # Informative message on what to do when the list is empty.
                cmds.text( label=maya.stringTable['y_Window.kClickToAddPattern' ], enable=False )
                cmds.text( label='' )

            cmds.symbolButton( image='RS_create_layer.png'
                             , command=callback_tool(self, partial(PatternWidget.on_add))
                             , annotation=maya.stringTable['y_Window.kAddListElement' ]
                             )
            cmds.text( label='' )
            cmds.text( label='' )

    #----------------------------------------------------------------------
    def patterns_to_use(self):
        '''Get the list of all non-empty patterns that are currently enabled'''
        patterns = []
        for pattern_index in range(len(self.pattern_values)):
            pattern = self.pattern_values[pattern_index]
            if pattern is not None and len(pattern) > 0 and self.enabled_values[pattern_index]:
                patterns.append( pattern )
        return patterns

    #----------------------------------------------------------------------
    def patterns_lists(self):
        '''
        Get the pair of lists of all non-empty patterns, (disabled, enabled)
        '''
        enabled = []
        disabled = []
        for pattern_index in range(len(self.pattern_values)):
            pattern = self.pattern_values[pattern_index]
            if pattern is not None and len(pattern) > 0:
                if self.enabled_values[pattern_index]:
                    enabled.append( pattern )
                else:
                    disabled.append( pattern )
        return (disabled, enabled)

    #----------------------------------------------------------------------
    @staticmethod
    def on_add(tool):
        '''
        Callback when the add button was clicked. Appends an empty pattern to
        the end of the list and updates the UI.
        '''
        tool.pattern_values.append( '' )
        tool.enabled_values.append( True )
        tool.create_ui()

    #----------------------------------------------------------------------
    @staticmethod
    def on_enable(tool, index):
        '''Callback when the checkbox enabling the "index"th pattern was clicked.
           Remembers the new enabled state.
        '''
        tool.enabled_values[index] = cmds.checkBox(tool.__checkbox_widgets[index], query=True, value=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_pattern(tool, index):
        '''Callback when the pattern text for the "index"th pattern was changed..
           Remembers the new pattern value.
        '''
        tool.pattern_values[index] = cmds.textField(tool.__pattern_widgets[index], query=True, text=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_delete(tool, index):
        '''
        Callback when the "index"th pattern was deleted. Removes the pattern from the list
        and updates the UI to reflect to the new list.
        '''
        del tool.pattern_values[index]
        del tool.enabled_values[index]
        tool.create_ui()

#======================================================================

class PathWidget(object):
    '''
    Class to manage creation and update of a variable length list path widget.

    The list is expanded and contracted dynamically by clicking on the +
    and trash icons rescpectively. Each path has a checkbox beside it
    so that it can be skipped without losing track of the path list.

        [X] Use Current Scene

        [X]   [  path ] [TRASH]
        [X]   [  path ] [TRASH]
        [ADD] [MVUP] [MVDN]
    '''

    def __init__(self, parent_widget):
        '''Initialize the widget information'''
        self.path_values       = []
        self.enabled_values    = []
        self.use_current_scene = True
        #
        self.__list_widget      = None
        self.__use_scene_widget = None
        self.__parent_widget    = parent_widget
        self.__delete_buttons   = []
        self.__path_widgets     = []
        self.__checkbox_widgets = []

        self.file_choices = { FILE_MODE_FILES : maya.stringTable['y_Window.kChooseInputFiles' ]
                            , FILE_MODE_DIR   : maya.stringTable['y_Window.kChooseInputDir'   ]
                            }

        # If a location is set for analytic files use that, otherwise use the current workspace
        if 'MAYA_ANALYTIC_PATH' in os.environ:
            self.__last_path = os.environ['MAYA_ANALYTIC_PATH'].split(':')[0]
        else:
            workspace = cmds.workspace(fullName=True)
            self.__last_path = os.path.join(workspace, 'scenes')

    #----------------------------------------------------------------------
    def create_ui(self):
        '''Create the generic text list UI and the buttons that control it'''
        # Clear out the existing child widgets since they will be rebuilt
        if self.__list_widget is not None:
            cmds.deleteUI( self.__list_widget, layout=True )
        self.__list_widget = cmds.columnLayout( parent=self.__parent_widget
                                              , adjustableColumn=True )
        self.__path_widgets    = []
        self.__checkbox_widgets   = []

        checkbox_annotation  = maya.stringTable['y_Window.kEnablePathAnnotation' ]
        directory_annotation = maya.stringTable['y_Window.kDirectoryAnnotation'  ]
        file_annotation      = maya.stringTable['y_Window.kFileAnnotation'       ]
        delete_annotation    = maya.stringTable['y_Window.kDeletePathAnnotation' ]

        with LayoutManager( self.__list_widget ):
            with LayoutManager( cmds.rowColumnLayout( numberOfColumns=1, columnAlign=[(1, 'left')]) ):
                self.__use_scene_widget = cmds.checkBox( value=self.use_current_scene
                             , changeCommand=callback_tool(self, partial(PathWidget.on_use_current_scene))
                             , label=maya.stringTable['y_Window.kUseCurrentScene' ]
                             , annotation=maya.stringTable['y_Window.kUseCurrentSceneAnnotation' ]
                             )

            with LayoutManager( cmds.rowColumnLayout( numberOfColumns=3
                                                    , enable=not self.use_current_scene
                                                    , columnSpacing=[(1,HSPC), (2,HSPC), (3,HSPC)]
                                                    , adjustableColumn=2
                                                    , columnAlign=[(1, 'center'), (2, 'left'), (3, 'left')]) ):
                if len(self.path_values) > 0:
                    for data_index in range(len(self.path_values)):
                        self.__checkbox_widgets.append( cmds.checkBox( value=self.enabled_values[data_index]
                                                 , changeCommand=callback_tool(self, partial(PathWidget.on_enable, index=data_index))
                                                 , label=''
                                                 , annotation=checkbox_annotation
                                                 )
                                             )
                        path = self.path_values[data_index]
                        if os.path.isdir(path):
                            text_annotation = directory_annotation
                        else:
                            text_annotation = file_annotation
                        self.__path_widgets.append( cmds.textField(
                                              text=path
                                            , width=TEXT_WIDTH
                                            , annotation=text_annotation
                                            , textChangedCommand=callback_tool(self, partial(PathWidget.on_path_edit, index=data_index))
                                            )
                                        )
                        self.__delete_buttons = cmds.symbolButton( image='RS_delete.png'
                                                    , command=callback_tool(self, partial(PathWidget.on_delete, index=data_index))
                                                    , annotation=delete_annotation
                                                    )
                else:
                    # Add padding in for the extra columns in the widget
                    cmds.text( label='' )
                    # Informative message on what to do when the list is empty.
                    cmds.text( label=maya.stringTable['y_Window.kClickToAddPath' ], enable=False )
                    cmds.text( label='' )

            with LayoutManager( cmds.rowColumnLayout( numberOfColumns=2
                                                    , enable=not self.use_current_scene
                                                    , columnSpacing=[(1,HSPC), (2,HSPC)]
                                                    , columnAlign=[(1, 'center'), (2, 'center')]) ):
                cmds.symbolButton( image='fileNew.png'
                                 , command=callback_tool(self, partial(PathWidget.on_add, mode=FILE_MODE_FILES))
                                 , annotation=maya.stringTable['y_Window.kAddFileToPath' ]
                                 )
                cmds.symbolButton( image='fileOpen.png'
                                 , command=callback_tool(self, partial(PathWidget.on_add, mode=FILE_MODE_DIR))
                                 , annotation=maya.stringTable['y_Window.kAddDirectoryToPath' ]
                                 )

    #----------------------------------------------------------------------
    def paths_to_use(self):
        '''
        Get the list of all non-empty paths that are currently enabled, unless
        use_current_scene is enabled, in which case return the empty list.
        '''
        paths = []
        if not cmds.checkBox( self.__use_scene_widget, query=True, value=True ):
            for path_index in range(len(self.path_values)):
                path = self.path_values[path_index]
                if path is not None and len(path) > 0 and self.enabled_values[path_index]:
                    paths.append( path )
        return paths

    #----------------------------------------------------------------------
    def paths_lists(self):
        '''
        Get the pair of lists of all non-empty paths, (disabled, enabled)
        '''
        enabled = []
        disabled = []
        for path_index in range(len(self.path_values)):
            path = self.path_values[path_index]
            if path is not None and len(path) > 0:
                if self.enabled_values[path_index]:
                    enabled.append( path )
                else:
                    disabled.append( path )
        return (disabled, enabled)

    #----------------------------------------------------------------------
    def set_use_current( self, use_current_scene ):
        '''Update the use_current_scene flag, along with the associated UI'''
        cmds.checkBox( self.__use_scene_widget, edit=True, value=use_current_scene )
        self.use_current_scene = use_current_scene

    #----------------------------------------------------------------------
    @staticmethod
    def on_use_current_scene(tool):
        '''Callback to selectively disable the file selector and buttons if only using the current scene'''
        tool.use_current_scene = cmds.checkBox( tool.__use_scene_widget, query=True, value=True )
        tool.create_ui()

    #----------------------------------------------------------------------
    @staticmethod
    def on_add(tool, mode):
        '''
        Callback when one of the add buttons was clicked. Lets the user select
        either a file or a directory, depending on mode, to add to the list.
        Nothing is added if the dialog is canceled.
        '''
        if mode == FILE_MODE_FILES:
            ok_caption = maya.stringTable['y_Window.kChooseFileButton' ]
            maya_files = maya.stringTable['y_Window.kChooseFileFormats' ]
            kwargs = { 'fileFilter' : maya_files }
        else:
            ok_caption = maya.stringTable['y_Window.kChooseDirectoryButton' ]
            kwargs = {}

        last_path = tool.__last_path
        if not os.path.isdir(last_path):
            last_path = os.path.dirname( last_path )

        result = cmds.fileDialog2( caption=tool.file_choices[mode]
                                 , fileMode=mode
                                 , okCaption=ok_caption
                                 , startingDirectory=last_path
                                 , dialogStyle=2
                                 , **kwargs
                                 )
        if result:
            assert len(result) >= 1
            for raw_path in result:
                chosen_path = os.path.normpath(raw_path)
                if os.path.isdir(chosen_path):
                    tool.__last_path = chosen_path
                else:
                    tool.__last_path = os.path.dirname( chosen_path )
                tool.path_values.append( chosen_path )
                tool.enabled_values.append( True )
            tool.create_ui()

    #----------------------------------------------------------------------
    @staticmethod
    def on_enable(tool, index):
        '''Callback when the checkbox enabling the "index"th path was clicked.
           Remembers the new enabled state.
        '''
        tool.enabled_values[index] = cmds.checkBox(tool.__checkbox_widgets[index], query=True, value=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_delete(tool, index):
        '''
        Callback when the "index"th path was deleted. Removes the path from the list
        and updates the UI to reflect to the new list.
        '''
        del tool.path_values[index]
        del tool.enabled_values[index]
        tool.create_ui()

    #----------------------------------------------------------------------
    @staticmethod
    def on_path_edit(tool, index):
        '''Callback when the path was manually edited.'''
        tool.path_values[index] = cmds.textField(tool.__path_widgets[index], query=True, text=True)

#======================================================================

class AnalyticsWindow(object):
    '''
    Helper class to manage all of the functions surrounding the creation and
    population of the analytics UI window.

    Create a window showing a visible interface to an analytics run. Shows
    a radio list with all available analytics, a selectable list of files
    and/or directories to include in the run, and controls for selecting
    all analytic options available through the Runner class.

        analytic_list       [Analytic]    List of analytics to be run, taken from the list of all analytics
        analytic_checkboxes {Name:Widget} Dictionary of analytic name mapped to the checkbox widget controlling them
        paths               [String Path] List of files or directories to be analyzed. (Empty means do the current scene.)
        anonymous_widget    String        Checkbox widget : make file and node names anonymous?
        descend_widget      String        Checkbox widget : walk subdirectories?
        details_widget      String        Checkbox widget : include full details in the output?
        force_widget        String        Checkbox widget : run analytic even if it is not out of date?
        log_file            File          Location for debugging output, None if not dumping it
        log_file_widget     String        File widget     : name of log file
        log_enabled_widget  String        Checkbox widget : log file enabled?
        options             {Key:Value}   Dictionary of options to be passed in to the analytics
        path_form           String        Form widget     : where paths are managed
        path_list           [Path]        List of paths to check for files to analyze
        path_widget_mgr     PathWidget    Owner of widgets where list of files and directories to analyze are entered
        progress_widget     String        Checkbox widget : show a progress bar while the analytics run?
        results_path        Directory     Root directory for analytics results.
        results_path_widget String        Text widget     : where the result path is entered
        skip                [String]      Regex list for files or directories to be skipped
        pattern_widget_mgr  PatternWidget Owner of widgets where filters for skipping are entered
        static_widget       String        Checkbox widget : only run static analytics, not scene-based ones?
        summary_widget      String        Checkbox widget : include the summary of all results in the output?
        __pattern_layout    String        Root widget of the pattern list section
        __path_layout       String        Root widget of the path list section
        __main_widget       String        Root widget of the entire window, for rebuilding
    '''
    #----------------------------------------------------------------------
    def __init__(self, analytic_list):
        '''
        Does nothing initially. This is a lightweight handle on the analytics
        window over top of the regular UI.
        '''
        self.analytic_list = analytic_list
        self.analytic_checkboxes = {}
        self.anonymous_widget = None
        self.descend_widget = None
        self.details_widget = None
        self.force_widget = None
        self.path_list = []
        self.path_widget = None
        self.pattern_widget_mgr = None
        self.path_widget_mgr = None
        self.progress_widget = None
        self.results_path = None
        self.results_path_widget = None
        self.log_file = None
        self.log_file_widget = None
        self.log_enabled_widget = None
        self.configuration_path = self.default_path()
        self.skip = []
        self.static_widget = None
        self.summary_widget = None
        self.__pattern_layout = None
        self.__path_layout = None
        self.__main_widget = None

    #----------------------------------------------------------------------
    def __initialize_from_json(self, json_data):
        '''
        Initialize all of the analytic configuration data from a JSON file
        and rebuild the UI using it.  It will be the same format used by
        __as_json to store the configuration.

        Anything not specifically mentioned in the JSON file will take its
        default value.
        '''
        config = json_data['Analytics Configuration']
        if 'analytics' in config:
            for analytic_name in self.analytic_checkboxes.keys():
                cmds.checkBox( self.analytic_checkboxes[analytic_name], edit=True, value=analytic_name in config['analytics'] )
        #
        self.set_anonymous( config.get('anonymous', False) )
        self.set_descend( config.get('descend', False) )
        self.set_details( config.get('details', False) )
        self.set_force( config.get('force', False) )
        self.set_report_progress( config.get('report_progress', False) )
        self.set_results_path( config.get('results_path', '') )
        self.set_log_file( config.get('log_file', '') )
        self.set_log_enabled( config.get('log_enabled', False) )
        self.set_static( config.get('static', False) )
        self.set_summary( config.get('summary', False) )
        self.path_widget_mgr.set_use_current( config.get('use_current_scene', True) )

        #
        self.path_widget_mgr.enabled_values = []
        self.path_widget_mgr.path_values = []
        if 'paths' in config:
            for path in config['paths']:
                self.path_widget_mgr.enabled_values.append( True )
                self.path_widget_mgr.path_values.append( path )
        if 'paths_disabled' in config:
            for path in config['paths_disabled']:
                self.path_widget_mgr.enabled_values.append( False )
                self.path_widget_mgr.path_values.append( path )
        #
        self.pattern_widget_mgr.enabled_values = []
        self.pattern_widget_mgr.pattern_values = []
        if 'skip' in config:
            for pattern in config['skip']:
                self.pattern_widget_mgr.enabled_values.append( True )
                self.pattern_widget_mgr.pattern_values.append( pattern )
        if 'skip_disabled' in config:
            for pattern in config['skip_disabled']:
                self.pattern_widget_mgr.enabled_values.append( False )
                self.pattern_widget_mgr.pattern_values.append( pattern )

        PathWidget.create_ui(self.path_widget_mgr)
        PatternWidget.create_ui(self.pattern_widget_mgr)

    #----------------------------------------------------------------------
    def __as_json(self):
        '''
        Return a JSON object containing the analytic configuration information.
        It will be the same format used by __initialize_from_json to load
        the configuration back.
        '''
        json_data = {}
        analytics_to_run = []
        for analytic_name in self.analytic_list.keys():
            if cmds.checkBox( self.analytic_checkboxes[analytic_name], query=True, value=True ):
                analytics_to_run.append( analytic_name )
        (disabled_paths, enabled_paths) = self.path_widget_mgr.paths_lists()
        (disabled_skip, enabled_skip) = self.pattern_widget_mgr.patterns_lists()
        config = { 'version' : '1.0'
                 , 'analytics'         : analytics_to_run
                 , 'anonymous'         : ANALYTICS_RUNNER.options['anonymous']
                 , 'descend'           : ANALYTICS_RUNNER.descend
                 , 'details'           : ANALYTICS_RUNNER.options['details']
                 , 'force'             : ANALYTICS_RUNNER.force
                 , 'log_file'          : ANALYTICS_RUNNER.logger.log_file_name
                 , 'log_enabled'       : ANALYTICS_RUNNER.logger.debugging
                 , 'paths'             : enabled_paths
                 , 'paths_disabled'    : disabled_paths
                 , 'report_progress'   : ANALYTICS_RUNNER.report_progress
                 , 'results_path'      : ANALYTICS_RUNNER.results_path
                 , 'skip'              : enabled_skip
                 , 'skip_disabled'     : disabled_skip
                 , 'static'            : ANALYTICS_RUNNER.static
                 , 'summary'           : ANALYTICS_RUNNER.options['summary']
                 , 'use_current_scene' : self.path_widget_mgr.use_current_scene
                 }
        json_data['Analytics Configuration'] = config
        return json_data

    #----------------------------------------------------------------------
    @staticmethod
    def default_path():
        '''Find a reasonable default path for results and scenes'''
        if 'MAYA_ANALYTIC_PATH' in os.environ:
            path = os.environ['MAYA_ANALYTIC_PATH'].split(':')[0]
        else:
            workspace = cmds.workspace(fullName=True)
            path = os.path.join(workspace, 'scenes')
        return path

    #----------------------------------------------------------------------
    @staticmethod
    def save_configuration( tool ):
        '''Take all of the current settings and save them to a file for loading'''
        path = os.path.dirname(tool.configuration_path)

        json_files = 'JSON Files (*.json);;All Files (*.*)'
        result = cmds.fileDialog2( caption=maya.stringTable['y_Window.kCaptionSaveConfig' ]
                                 , fileMode=FILE_MODE_CREATE
                                 , okCaption=maya.stringTable['y_Window.kOkSave' ]
                                 , startingDirectory=path
                                 , fileFilter=json_files
                                 , dialogStyle=2
                                 )
        if result:
            assert len(result) == 1
            chosen_path = os.path.normpath(result[0])
            tool.configuration_path = chosen_path
            with open(chosen_path, 'w') as config_file:
                json.dump( tool.__as_json(), config_file, indent=4 )

    #----------------------------------------------------------------------
    @staticmethod
    def load_configuration( tool ):
        '''Select a file and populate the configuration with the settings in the file'''
        path = os.path.dirname(tool.configuration_path)

        json_files = 'JSON Files (*.json);;All Files (*.*)'
        result = cmds.fileDialog2( caption=maya.stringTable['y_Window.kCaptionLoadConfig' ]
                                 , fileMode=FILE_MODE_FILE
                                 , okCaption=maya.stringTable['y_Window.kOkLoadConfig' ]
                                 , startingDirectory=path
                                 , fileFilter=json_files
                                 , dialogStyle=2
                                 )
        if result:
            try:
                assert len(result) == 1
                chosen_path = os.path.normpath(result[0])
                tool.configuration_path = chosen_path
                with open(chosen_path, 'r') as config_file:
                    tool.__initialize_from_json( json.load( config_file ) )
            except Exception, ex:
                print 'ERR: Could not load analytics : {}'.format(ex)

    #----------------------------------------------------------------------
    @staticmethod
    def run_analytics( tool, operation ):
        '''
        Run all of the selected analytics with the current options.

        tool: The Window object calling back to the function
        operation: RUN_ANALYTICS = Run the analytics specified by the configuration
                   LIST_ANALYTICS = List the analytics that would be run according to the configuration
                   SHOW_ANALYTIC_COMMAND = Print the Python script that would run the analytics
        '''
        debug( '{} the analytics'.format(['Running','Listing','Showng the Command to run'][operation]) )
        analytics_to_run = []
        for analytic_name in tool.analytic_list.keys():
            if cmds.checkBox( tool.analytic_checkboxes[analytic_name], query=True, value=True ):
                analytics_to_run.append( analytic_name )

        ANALYTICS_RUNNER.analytics = analytics_to_run
        ANALYTICS_RUNNER.skip = tool.pattern_widget_mgr.patterns_to_use()
        ANALYTICS_RUNNER.paths = tool.path_widget_mgr.paths_to_use()

        debug( 'RUN\n{}\n'.format(ANALYTICS_RUNNER) )

        if operation == RUN_ANALYTICS:
            ANALYTICS_RUNNER.list_only = False
            ANALYTICS_RUNNER.run()
        elif operation == LIST_ANALYTICS:
            ANALYTICS_RUNNER.list_only = True
            ANALYTICS_RUNNER.run()
        else:
            paths = ANALYTICS_RUNNER.paths
            if tool.path_widget_mgr.use_current_scene:
                paths = None
            print '''import maya.analytics.Runner as Runner
import maya.analytics.Logger as Logger
runner = Runner()
runner.analytics = {}
runner.descend = {}
runner.force = {}
runner.options['anonymous'] = {}
runner.options['details'] = {}
runner.options['summary'] = {}
runner.paths = {}
runner.report_progress = {}
runner.results_path = {}
runner.logger = Logger(debugging={}, file_name='{}')
runner.skip = {}
runner.static = {}
runner.run()
'''.format( ANALYTICS_RUNNER.analytics
          , ANALYTICS_RUNNER.descend
          , ANALYTICS_RUNNER.force
          , ANALYTICS_RUNNER.options['anonymous']
          , ANALYTICS_RUNNER.options['details']
          , ANALYTICS_RUNNER.options['summary']
          , paths
          , ANALYTICS_RUNNER.report_progress
          , ANALYTICS_RUNNER.results_path
          , ANALYTICS_RUNNER.logger.debugging
          , ANALYTICS_RUNNER.logger.log_file_name
          , ANALYTICS_RUNNER.skip
          , ANALYTICS_RUNNER.static
          )

    #----------------------------------------------------------------------
    def set_anonymous( self, anonymous ):
        '''Update the anonymous flag, along with the associated UI'''
        cmds.checkBox(self.anonymous_widget, edit=True, value=anonymous)
        ANALYTICS_RUNNER.set_option( 'anonymous', anonymous )

    #----------------------------------------------------------------------
    def set_descend( self, descend ):
        '''Update the descend flag, along with the associated UI'''
        cmds.checkBox(self.descend_widget, edit=True, value=descend)
        ANALYTICS_RUNNER.descend = descend

    #----------------------------------------------------------------------
    def set_details( self, details ):
        '''Update the details flag, along with the associated UI'''
        cmds.checkBox(self.details_widget, edit=True, value=details)
        ANALYTICS_RUNNER.set_option( 'details', details )

    #----------------------------------------------------------------------
    def set_force( self, force ):
        '''Update the force flag, along with the associated UI'''
        cmds.checkBox(self.force_widget, edit=True, value=force)
        ANALYTICS_RUNNER.force = force

    #----------------------------------------------------------------------
    def set_report_progress( self, report_progress ):
        '''Update the results_path value, along with the associated UI'''
        cmds.checkBox(self.progress_widget, edit=True, value=report_progress)
        ANALYTICS_RUNNER.report_progress = report_progress

    #----------------------------------------------------------------------
    def set_results_path( self, results_path ):
        '''Update the results_path value, along with the associated UI'''
        new_path = results_path if results_path is not None else ''
        cmds.textField(self.results_path_widget, edit=True, text=new_path)
        ANALYTICS_RUNNER.results_path = results_path

    #----------------------------------------------------------------------
    def set_log_file( self, log_file_name ):
        '''Update the log_file value, along with the associated UI'''
        cmds.textField(self.log_file_widget, edit=True, text=log_file_name)
        debugging = cmds.checkBox(self.log_enabled_widget, query=True, value=True)
        ANALYTICS_RUNNER.logger = Logger(debugging=debugging, file_name=log_file_name)

    #----------------------------------------------------------------------
    def set_log_enabled( self, enabled ):
        '''Update the log_file value, along with the associated UI'''
        cmds.checkBox(self.log_enabled_widget, edit=True, value=enabled)
        log_file_name = ANALYTICS_RUNNER.logger.log_file_name
        ANALYTICS_RUNNER.logger = Logger(debugging=enabled, file_name=log_file_name)

    #----------------------------------------------------------------------
    def set_static( self, static ):
        '''Update the static flag, along with the associated UI'''
        cmds.checkBox(self.static_widget, edit=True, value=static)
        AnalyticsWindow.on_select_static_analytics( self )

    #----------------------------------------------------------------------
    def set_summary( self, summary ):
        '''Update the summary flag, along with the associated UI'''
        cmds.checkBox(self.summary_widget, edit=True, value=summary)
        ANALYTICS_RUNNER.set_option( 'summary', summary )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_static_analytics(tool):
        '''Callback to refresh analytic enabled state when switching static styles'''
        ANALYTICS_RUNNER.static = cmds.checkBox(tool.static_widget, query=True, value=True)
        for analytic_name, checkbox in tool.analytic_checkboxes.iteritems():
            is_static = tool.analytic_list[analytic_name].is_static
            cmds.checkBox( checkbox, edit=True, enable=(is_static == ANALYTICS_RUNNER.static) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_report_progress(tool):
        '''Callback to set report_progress option'''
        ANALYTICS_RUNNER.report_progress = cmds.checkBox(tool.progress_widget, query=True, value=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_force(tool):
        '''Callback to set force_run option'''
        ANALYTICS_RUNNER.force = cmds.checkBox(tool.force_widget, query=True, value=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_anonymous(tool):
        '''Callback to set anonymous option'''
        ANALYTICS_RUNNER.set_option( 'anonymous', cmds.checkBox(tool.anonymous_widget, query=True, value=True) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_details(tool):
        '''Callback to set details option'''
        ANALYTICS_RUNNER.set_option('details', cmds.checkBox(tool.details_widget, query=True, value=True) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_summary(tool):
        '''Callback to set summary option'''
        ANALYTICS_RUNNER.set_option('summary', cmds.checkBox(tool.summary_widget, query=True, value=True) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_descend(tool):
        '''Callback to set descend option'''
        ANALYTICS_RUNNER.descend = cmds.checkBox(tool.descend_widget, query=True, value=True)

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_results_path(tool):
        '''
        Callback when the results path icon was clicked, which will find a
        new path to use for results using the file browser.
        Nothing is changed if the dialog is canceled.
        '''
        ok_caption = maya.stringTable['y_Window.kChooseResultsPathOk' ]
        path_caption = maya.stringTable['y_Window.kChooseResultsPath' ]

        last_path = tool.results_path
        if last_path is None:
            last_path = tool.default_path()

        result = cmds.fileDialog2( caption=path_caption
                                 , fileMode=FILE_MODE_DIR
                                 , okCaption=ok_caption
                                 , startingDirectory=last_path
                                 , dialogStyle=2
                                 )
        if result:
            assert len(result) == 1
            chosen_path = os.path.normpath(result[0])
            tool.set_results_path( chosen_path )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_log_file(tool):
        '''
        Callback when the logger path icon was clicked, which will find a
        new path to use for logging debugging information using the file browser.
        Nothing is changed if the dialog is canceled.
        '''
        ok_caption = maya.stringTable['y_Window.kChooseLogFileOk' ]
        path_caption = maya.stringTable['y_Window.kChooseLogFile' ]

        if tool.log_file is None:
            last_path = tool.default_path()
        else:
            last_path = os.path.dirname(tool.log_file)

        result = cmds.fileDialog2( caption=path_caption
                                 , fileMode=FILE_MODE_CREATE
                                 , okCaption=ok_caption
                                 , startingDirectory=last_path
                                 , dialogStyle=2
                                 )
        if result:
            assert len(result) == 1
            chosen_path = os.path.normpath(result[0])
            tool.log_file = chosen_path
            new_path = chosen_path if chosen_path is not None else ''
            tool.set_log_file( new_path )

    #----------------------------------------------------------------------
    @staticmethod
    def on_log_file_edit(tool):
        '''
        Callback when the log file was manually edited.
        '''
        tool.set_log_file( cmds.textField(tool.log_file_widget, query=True, text=True) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_log_enabled(tool):
        '''Callback to set log file enabled option'''
        tool.set_log_enabled( cmds.checkBox(tool.log_enabled_widget, query=True, value=True) )

    #----------------------------------------------------------------------
    @staticmethod
    def on_results_path_edit(tool):
        '''
        Callback when the results path was manually edited. Maps an empty
        string to None since that is what the Runner expects
        '''
        results_path = cmds.textField(tool.results_path_widget, query=True, text=True)
        ANALYTICS_RUNNER.results_path = results_path if results_path != '' else None

    #----------------------------------------------------------------------
    @staticmethod
    def on_select_all_analytics(tool):
        '''Callback to select all available analytics'''
        for checkbox in tool.analytic_checkboxes.values():
            cmds.checkBox( checkbox, edit=True, value=True )

    #----------------------------------------------------------------------
    @staticmethod
    def on_deselect_all_analytics(tool):
        '''Callback to deselect all available analytics'''
        for checkbox in tool.analytic_checkboxes.values():
            cmds.checkBox( checkbox, edit=True, value=False )

    #----------------------------------------------------------------------
    @staticmethod
    def on_info(tool, analytic_name):
        '''
        Callback when the info button is hit for the named analytic.
        Pop open a message box with the detailed help provided by the analytic.
        '''
        window_title = maya.stringTable['y_Window.kAnalyticInfo' ].format(analytic_name)
        window_message = ''
        try:
            for line in tool.analytic_list[analytic_name].ANALYTIC_DESCRIPTION_DETAILED:
                window_message += line
        except:
            window_message += maya.stringTable['y_Window.kAnalyticInfoNotAvailable' ]

        # Build a small scrollable window to view the analytic documentation. Some of them
        # have a lot of information so showMessageBox wasn't sufficient, it has to scroll.
        info_window = cmds.window( 'AnalyticInfo' , title=window_title )
        with LayoutManager( info_window ):
            with LayoutManager( cmds.scrollLayout() ):
                # Fixed Width so that ASCII alignment is preserved.
                # Left aligned since that's what the Python docs use.
                cmds.text( label=window_message, font='fixedWidthFont', align='left' )
        cmds.showWindow( info_window )

    #----------------------------------------------------------------------
    def __build_analytics_window(self):
        '''
        Create the window with the analytics information in it.
        Call this multiple times to rebuild the interior. The main window
        will stay open all the tim.
        '''
        global ANALYTICS_WINDOW
        if ANALYTICS_WINDOW is None:
            ANALYTICS_WINDOW = cmds.window( 'AnalyticsUI'
                                          , title=maya.stringTable['y_Window.kAnalyticObjectsTitle' ]
                                          , iconName=maya.stringTable['y_Window.kAnalyticObjectIconName' ]
                                          )
        if self.__main_widget is not None:
            cmds.deleteUI( self.__main_widget )

        self.__main_widget = cmds.scrollLayout( parent=ANALYTICS_WINDOW, childResizable=True )
        with LayoutManager(self.__main_widget):
            with LayoutManager(cmds.columnLayout( adjustableColumn=True )):
                #----------------------------------------------------------------------
                #
                # Operations section. Consists of three buttons that will either run the
                # analytics as selected, list them, or print the Python that will run
                # them.
                #
                #           +-----+  +------+  +--------------+    +----+ +----+
                #  Actions: | Run |  | List |  | Show Command |    |SAVE| |LOAD|
                #           +-----+  +------+  +--------------+    +----+ +----+
                #
                with LayoutManager(cmds.rowColumnLayout( numberOfColumns=5
                                        , columnAlign=[(1, 'right'), (2, 'center'), (3, 'center'), (4, 'center'), (5, 'center')]
                                        , columnSpacing=[(1,HSPC), (2,HSPC), (3,HSPC), (4,BUTTON_WIDTH), (5,HSPC)]
                                        )):
                    cmds.button( label=maya.stringTable['y_Window.kRunAnalytics']
                               , annotation=maya.stringTable['y_Window.kRunAnalyticsAnnotation']
                               , command=callback_tool(self, partial(AnalyticsWindow.run_analytics, operation=RUN_ANALYTICS)) )
                    cmds.button( label=maya.stringTable['y_Window.kListAnalytics']
                               , annotation=maya.stringTable['y_Window.kListAnalyticsAnnotation']
                               , command=callback_tool(self, partial(AnalyticsWindow.run_analytics, operation=LIST_ANALYTICS)) )
                    cmds.button( label=maya.stringTable['y_Window.kShowAnalyticCommand']
                               , annotation=maya.stringTable['y_Window.kShowCommandAnnotation']
                               , command=callback_tool(self, partial(AnalyticsWindow.run_analytics, operation=SHOW_ANALYTIC_COMMAND)) )
                    cmds.symbolButton( image='fileSave.png'
                                     , command=callback_tool(self, partial(AnalyticsWindow.save_configuration))
                                     , annotation=maya.stringTable['y_Window.kFileSaveAnnotation' ]
                                     )
                    cmds.symbolButton( image='fileOpen.png'
                                     , command=callback_tool(self, partial(AnalyticsWindow.load_configuration))
                                     , annotation=maya.stringTable['y_Window.kFileLoadAnnotation' ]
                                     )

                #----------------------------------------------------------------------
                #
                # Frame consisting of all the simple options for running analytics:
                #
                #      [  ] Report Progress
                #      [  ] Force Run
                #      [  ] Show Details
                #      [  ] Show Summary
                #      [  ] Include Subdirectories
                #      [  ] anonymous Names
                #
                with LayoutManager(cmds.frameLayout( label=maya.stringTable['y_Window.kOptions' ], marginWidth=25, marginHeight=4 )):
                    with LayoutManager( cmds.columnLayout( adjustableColumn=True
                                      , columnAlign='center'
                                      ) ):

                        self.progress_widget = cmds.checkBox( value=ANALYTICS_RUNNER.report_progress
                                     , label=maya.stringTable['y_Window.kReportProgress' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_report_progress))
                                     , annotation=maya.stringTable['y_Window.kReportProgressInfo' ]
                                     )
                        self.force_widget = cmds.checkBox( value=ANALYTICS_RUNNER.force
                                     , label=maya.stringTable['y_Window.kForceRun' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_force))
                                     , annotation=maya.stringTable['y_Window.kForceRunInfo' ]
                                     )
                        self.details_widget = cmds.checkBox( value=ANALYTICS_RUNNER.options['details']
                                     , label=maya.stringTable['y_Window.kShowDetails' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_details))
                                     , annotation=maya.stringTable['y_Window.kShowDetailsInfo' ]
                                     )
                        self.summary_widget = cmds.checkBox( value=ANALYTICS_RUNNER.options['summary']
                                     , label=maya.stringTable['y_Window.kShowSummary' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_summary))
                                     , annotation=maya.stringTable['y_Window.kShowSummaryInfo' ]
                                     )
                        self.descend_widget = cmds.checkBox( value=ANALYTICS_RUNNER.descend
                                     , label=maya.stringTable['y_Window.kDescend' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_descend))
                                     , annotation=maya.stringTable['y_Window.kDescendInfo' ]
                                     )
                        self.anonymous_widget = cmds.checkBox( value=ANALYTICS_RUNNER.options['anonymous']
                                     , label=maya.stringTable['y_Window.kShowAnonymous' ]
                                     , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_anonymous))
                                     , annotation=maya.stringTable['y_Window.kShowAnonymousInfo' ]
                                     )
                        with LayoutManager( cmds.rowColumnLayout( numberOfColumns=4
                                                                , columnAlign=[(1, 'center'), (2, 'center'), (3, 'center'), (4, 'left')]
                                                                , adjustableColumn=3
                                                                , columnSpacing=[(1,HSPC), (2,HSPC), (3,HSPC), (4,HSPC)] ) ):
                            cmds.text( label='' )
                            cmds.symbolButton( image='fileOpen.png'
                                             , command=callback_tool(self, partial(AnalyticsWindow.on_select_results_path))
                                             , annotation=maya.stringTable['y_Window.kSelectResultsPath' ]
                                             )
                            # Results path should be None when no path is specified so map the
                            # empty string to it.
                            results_path = ANALYTICS_RUNNER.results_path if ANALYTICS_RUNNER.results_path is not None else ''
                            self.results_path_widget = cmds.textField(
                                                  text=results_path
                                                , width=TEXT_WIDTH
                                                , annotation=maya.stringTable['y_Window.kResultsPathAnnotation' ]
                                                , enterCommand=callback_tool(self, partial(AnalyticsWindow.on_results_path_edit))
                                                )
                            cmds.text( label=maya.stringTable['y_Window.kResultsPathLabel' ] )
                            #----------------------------------------
                            self.log_enabled_widget = cmds.checkBox( value=ANALYTICS_RUNNER.logger.debugging
                                         , label=''
                                         , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_log_enabled))
                                         , annotation=maya.stringTable['y_Window.kShowLogEnabledInfo' ]
                                         )
                            cmds.symbolButton( image='fileOpen.png'
                                             , command=callback_tool(self, partial(AnalyticsWindow.on_select_log_file))
                                             , annotation=maya.stringTable['y_Window.kSelectLogFile' ]
                                             )
                            self.log_file_widget = cmds.textField(
                                                  text=ANALYTICS_RUNNER.logger.log_file_name
                                                , width=TEXT_WIDTH
                                                , annotation=maya.stringTable['y_Window.kLogFileAnnotation' ]
                                                , enterCommand=callback_tool(self, partial(AnalyticsWindow.on_log_file_edit))
                                                )
                            cmds.text( label=maya.stringTable['y_Window.kLogFileLabel' ] )


                #----------------------------------------------------------------------
                #
                # List all of the available analytics, with checkboxes for selective
                # enabling and disabling. Includes "Select All" and "Deselect All"
                # buttons as shortcuts. If the "Static Analytics" option is selected
                # then all static analytics are greyed out, otherwise the non-static
                # ones are greyed out. Laid out in 3 columns to save space.
                #
                #    +------------+   +--------------+
                #    | Select All |   | Deselect All |  [  ] Static Analytics
                #    +------------+   +--------------+
                #
                #    [?] [  ] Analytic1   [?] [  ] Analytic2   [?] [  ] Analytic3
                #    ...
                #
                #
                with LayoutManager( cmds.frameLayout( label=maya.stringTable['y_Window.kAnalytics' ] )):
                    analytic_list_form = cmds.formLayout( numberOfDivisions=100 )
                    with LayoutManager( analytic_list_form ):
                        analytic_list_buttons = cmds.rowColumnLayout( numberOfColumns=3
                                                                    , columnAlign=[(1, 'center'), (2, 'center'), (3, 'center')]
                                                                    , columnSpacing=[(1,HSPC), (2,HSPC), (3,HSPC)] )
                        with LayoutManager(analytic_list_buttons):
                            cmds.button( label=maya.stringTable['y_Window.kSelectAllAnalytics']
                                       , command=callback_tool(self, partial(AnalyticsWindow.on_select_all_analytics))
                                       )
                            cmds.button( label=maya.stringTable['y_Window.kDeselectAllAnalytics']
                                       , command=callback_tool(self, partial(AnalyticsWindow.on_deselect_all_analytics))
                                       )
                            self.static_widget = cmds.checkBox( value=ANALYTICS_RUNNER.static
                                         , label=maya.stringTable['y_Window.kShowStatic' ]
                                         , changeCommand=callback_tool(self, partial(AnalyticsWindow.on_select_static_analytics))
                                         , annotation=maya.stringTable['y_Window.kShowStaticInfo' ]
                                         )

                        #----------------------------------------------------------------------
                        analytic_list_items = cmds.rowColumnLayout( numberOfColumns=6
                                                                  , columnAlign=[(1, 'right'), (2, 'left'),  (3, 'right')
                                                                                ,(4, 'left'),  (5, 'right'), (6, 'left')]
                                                                  , columnSpacing=[(1,HSPC),  (2,HSPC), (3,HSPC*2)
                                                                                  ,(4, HSPC), (5, HSPC*2),  (6, HSPC)]
                                                                  )

                        with LayoutManager(analytic_list_items):
                            info_annotation = maya.stringTable['y_Window.kInfoAnnotation' ]
                            self.analytic_checkboxes = {}
                            for analytic_name in sorted(self.analytic_list.keys()):
                                cmds.symbolButton( image='info.png'
                                                 , command=callback_tool(self, partial(AnalyticsWindow.on_info, analytic_name=analytic_name))
                                                 , annotation=info_annotation
                                                 )
                                analytic_annotation = self.analytic_list[analytic_name].ANALYTIC_DESCRIPTION_SHORT
                                analytic_label = self.analytic_list[analytic_name].ANALYTIC_LABEL
                                self.analytic_checkboxes[analytic_name] = cmds.checkBox( label=analytic_label
                                                      , enable=not self.analytic_list[analytic_name].is_static
                                                      , annotation=analytic_annotation
                                                      )

                    cmds.formLayout( analytic_list_form, edit=True
                                   , attachForm=[ (analytic_list_buttons, 'top',    VSPC)
                                                , (analytic_list_buttons, 'left',   HSPC)
                                                , (analytic_list_buttons, 'right',  HSPC)
                                                , (analytic_list_items,   'left',   HSPC)
                                                , (analytic_list_items,   'right',  HSPC)
                                                , (analytic_list_items,   'bottom', VSPC)
                                                ]
                                   , attachControl=[analytic_list_buttons, 'bottom',  VSPC, analytic_list_items]
                                   )

                #----------------------------------------------------------------------
                #
                # The file location selection is done in two parts. The selector lets you
                # choose to run the current scene instead of the lists of files. If you
                # select the lists of files then the list widget below is enabled where
                # you can add, enable, or remove directories from your list to search.
                #
                #    [ ] Use Current Scene
                #
                #    [X] [  name_of_directory   ] [ - ]
                #    [X] [  name_of_directory   ] [ - ]
                #    [ +F ] [ +D ]
                #
                self.__path_layout = cmds.frameLayout( label=maya.stringTable['y_Window.kPathTitle' ]
                                        , annotation=maya.stringTable['y_Window.kPathAnnotation' ]
                                        , marginWidth=25, marginHeight=4, collapsable=True, collapse=True )
                # Get out of the frame layout, it will be used explicitly in create_ui
                with LayoutManager(self.__path_layout):
                    self.path_widget_mgr = PathWidget( self.__path_layout )
                    self.path_widget_mgr.create_ui()

                #----------------------------------------------------------------------
                #
                # This section lists the patterns (in Python regex form) to match on
                # files to be skipped - e.g. "references/" to skip everything in the
                # "references" subdirectories.
                #
                # The list is expanded and contracted dynamically by clicking on the +
                # and trash icons rescpectively. Each pattern has a checkbox beside it
                # so that it can be skipped without losing track of what the pattern is.
                #
                #    [X] [  pattern string   ] TRASH
                #    [X] [  pattern string   ] TRASH
                #    ADD
                #
                self.__pattern_layout = cmds.frameLayout( label=maya.stringTable['y_Window.kSkipTitle' ]
                                        , annotation=maya.stringTable['y_Window.kSkipAnnotation' ]
                                        , marginWidth=25, marginHeight=4, collapsable=True, collapse=True )
                # Get out of the frame layout, it will be used explicitly in create_ui
                with LayoutManager(self.__pattern_layout):
                    self.pattern_widget_mgr = PatternWidget( self.__pattern_layout )
                    self.pattern_widget_mgr.create_ui()

    #----------------------------------------------------------------------
    def show_window(self):
        '''
        If the window already exists then pop it up, otherwise create it
        and then pop it up. The window's contents are not sync'd with the
        outside world so it's possible to have references to files or
        directories that no longer exist in the window.

        Returns the name of the window.
        '''
        global ANALYTICS_WINDOW
        # If calling this for the first time then build the window.
        if ANALYTICS_WINDOW is None or not cmds.window( ANALYTICS_WINDOW, exists=True ):
            ANALYTICS_WINDOW = None
            self.__build_analytics_window()

        cmds.showWindow( ANALYTICS_WINDOW )
        return ANALYTICS_WINDOW

#----------------------------------------------------------------------
def analytics_ui():
    '''
    Shallow interface to the analytics Window object, which only has
    the single external function of showing the Window.

    Returns the name of the analytics window, in case you want to
    delete it.
    '''
    analytics_window = AnalyticsWindow( list_analytics() )
    return analytics_window.show_window()
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
