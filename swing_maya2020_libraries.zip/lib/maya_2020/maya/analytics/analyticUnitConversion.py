"""
Scene stats collection for the types of connections requiring the use of unit conversion nodes.
"""
import maya
maya.utils.loadStringResourcesForModule(__name__)

import maya.cmds as cmds
from .BaseAnalytic import BaseAnalytic, OPTION_DETAILS
from .decorators import addMethodDocs,addHelp,makeAnalytic

kAnalyticLabel = maya.stringTable['y_analyticUnitConversion.kAnalyticLabel' ]
kAnalyticDescriptionShort = maya.stringTable['y_analyticUnitConversion.kAnalyticDescriptionShort' ]

# Dictionary keys for the main sections
KEY_BEFORE = 'before'
KEY_AFTER = 'after'
KEY_CONVERSION = 'conversion'

# Dictionary key for the detail section
KEY_DETAILS = 'details'

# Dictionary key for the main section
KEY_ROOT = 'unitConversion'


@addMethodDocs
@addHelp
@makeAnalytic(False)
class analyticUnitConversion(BaseAnalytic):
    """
    This analytic collects the types of nodes before and after a unit conversion node.

    The output consists of a dictionary entry with a before and after section.
    The 'before' section contains node type/count pairs indicating how many times
    they appear before a unit conversion node. The 'after' section contains node
    type/count pairs indicating how many times they appear after a unit conversion
    node. ('Before' and 'after' refer to upstream and downstream connections
    respectively.) The 'conversion' section contains counts of the unit conversion
    nodes that use various conversion factors.

        "before" : {
            "animCurveTL" : 3,
            "animCurveTU" : 1
        },
        "after" : {
            "transform" : 3,
            "mesh" : 1
        }
        "conversion" : {
            1.2345 : 2,
            7.123 : 2
        }

    If the 'details' option is used then the set of all unit conversion connections
    is output as a dictionary where the key is the unit conversion node type and
    the values are lists of pairs

        "details" : {
            "unitToTimeConversion" : [
                [ "node1.tx", "node2.input1"],
                [ "node1.ty", "node2.input1"],
                [ "node1.tz", "node2.input1"]
            ],
            "timeToUnitConversion" : [
                [ "node1_tx", "node1.dynInput1"],
                [ "node1_ty", "node1.dynInput2"],
                [ "node1_tz", "node1.dynInput3"]
            ]
        }
    """
    ANALYTIC_LABEL = kAnalyticLabel
    ANALYTIC_DESCRIPTION_SHORT = kAnalyticDescriptionShort

    #----------------------------------------------------------------------
    def run(self):
        """
        Run the analytic on the current scene.
        :return: JSON results as described in the class doc
        """
        json_data = { KEY_BEFORE : {}, KEY_AFTER : {}, KEY_CONVERSION : {} }
        before_counts = json_data[KEY_BEFORE]
        after_counts = json_data[KEY_AFTER]
        conversions = json_data[KEY_CONVERSION]
        details = {}

        # Gather all of the unit conversion nodes for processing
        unit_conversion_nodes = cmds.ls( type='unitConversion' )

        # Walk the list of unit conversion nodes, adding their information as we go
        for unit_conversion_node in unit_conversion_nodes:
            conversion_factor = cmds.getAttr( '{}.cf'.format(unit_conversion_node) )
            befores = cmds.listConnections( '{}.i'.format(unit_conversion_node), plugs=True, destination=False, source=True )
            afters = cmds.listConnections( '{}.o'.format(unit_conversion_node), plugs=True, destination=True, source=False )

            # Catch the odd case of unconnected unit conversion nodes
            befores = befores or []
            afters = afters or []

            # Increment the conversion factor entry
            conversions[conversion_factor] = conversions.get( conversion_factor, 0 ) + 1

            # Increment the before node type
            for before in befores:
                (before_node, _) = before.split('.', 1)
                before_node_type = cmds.nodeType( before_node )
                before_counts[before_node_type] = before_counts.get( before_node_type, 0 ) + 1

            # Increment all of the after node types
            for after in afters:
                (after_node, _) = after.split('.', 1)
                after_node_type = cmds.nodeType( after_node )
                after_counts[after_node_type] = after_counts.get( after_node_type, 0 ) + 1

            # Add details if requested
            if self.option(OPTION_DETAILS):
                conversion_type = cmds.nodeType( unit_conversion_node )
                details[conversion_type] = details.get(conversion_type, []) + [befores + afters]

        # If the details were requested add them to the final dictionary
        if self.option(OPTION_DETAILS):
            json_data[KEY_DETAILS] = details

        return json_data

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
