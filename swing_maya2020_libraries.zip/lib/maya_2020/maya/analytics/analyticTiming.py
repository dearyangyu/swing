"""
Gather basic scene timing information from the profiler,
with and without the invisibility evaluator active.
"""
import maya
maya.utils.loadStringResourcesForModule(__name__)

import os
import re
import json
import maya.cmds as cmds
from  maya.debug.emModeManager import emModeManager
from .BaseAnalytic import BaseAnalytic
from .decorators import addMethodDocs,addHelp,makeAnalytic

kAnalyticLabel = maya.stringTable['y_analyticTiming.kAnalyticLabel' ]
kAnalyticDescriptionShort = maya.stringTable['y_analyticTiming.kAnalyticDescriptionShort' ]

# List of EM modes to be measured
MODE_LIST = ['emp-invisibility', 'emp+invisibility']

#======================================================================

@addMethodDocs
@addHelp
@makeAnalytic(False)
class analyticTiming(BaseAnalytic):
    """
    Examine timing information for basic operations in different modes.
    The list of modes can be modified as needs change by altering the
    MODE_LIST value in the script.

    WARNING: Since this test gets timing for file-new you will lose your
             data if you run it on the current scene.

    It measures the following events for each of the modes, in microseconds. If
    multiple instances of the event are found then the last one found is used,
    under the assumption that the state is most steady by then.

        EvaluationGraphConstruction    : Graph build time
        EvaluationGraphPartitioning    : Graph partitioning time
        EvaluationGraphExecution       : Graph execution time
        Vp2SceneRender                 : Viewport 2 rendering time
        Vp1SceneRender                 : Legacy Viewport rendering time
        ClusterCount                   : Total number of custom evaluator clusters
        ClusterNodeCount               : Total number of nodes in custom evaluator clusters
        InvisibilityClusterCount       : Total number of invisibility clusters
        InvisibilityClusterNodeCount   : Total number of nodes in invisibility clusters
        InvisibilityCreateClusters     : Time taken by the invisibility evaluator to create its clusters
        InvisibilityDiscover           : Time taken by the invisibility evaluator to discover invisible nodes
        InvisibilityMarkNodes          : Time taken by the invisibility evaluator to mark its nodes
        InvisibilityCreatePartitioning : Time taken by the invisibility evaluator to create its partitions

    Note: InvisibilityCreateClusters is the parent of these three steps so don't add them:
        - InvisibilityDiscover
        - InvisibilityMarkNodes
        - InvisibilityCreatePartitioning

    and these, which are independent of the evaluator configuration:
        FileNew        : Time to empty the scene of the current file, in seconds
        CycleCount     : Total number of cycle clusters
        CycleNodeCount : Total number of nodes in cycle clusters

    Example output running in parallel mode both with and without the
    invisibility for a scene that uses VP2:

        "output" : {
            "emp-invisibility" : {
                "EvaluationGraphConstruction"    : 5632,
                "EvaluationGraphPartitioning"    : 392,
                "EvaluationGraphExecution"       : 2020211,
                "Vp2SceneRender"                 : 7152,
                "Vp1SceneRender"                 : 0,
                "ClusterCount"                   : 72,
                "ClusterNodeCount"               : 1230,
                "InvisibilityClusterCount"       : 0,
                "InvisibilityClusterNodeCount"   : 0,
                "InvisibilityDiscover"           : 0,
                "InvisibilityCreateClusters"     : 0,
                "InvisibilityMarkNodes"          : 0,
                "InvisibilityCreatePartitioning" : 0
            },
            "emp+invisibility" : {
                "EvaluationGraphConstruction"    : 7801,
                "EvaluationGraphPartitioning"    : 738,
                "EvaluationGraphExecution"       : 19374,
                "Vp2SceneRender"                 : 7326,
                "Vp1SceneRender"                 : 0,
                "ClusterCount"                   : 129,
                "ClusterNodeCount"               : 7183,
                "InvisibilityClusterCount"       : 11,
                "InvisibilityClusterNodeCount"   : 11,
                "InvisibilityDiscover"           : 12341,
                "InvisibilityCreateClusters"     : 123,
                "InvisibilityMarkNodes"          : 1110,
                "InvisibilityCreatePartitioning" : 84
            },
            "CycleCount"     : 3,
            "CycleNodeCount" : 14,
            "FileNew"        : 4.19238
        }
    """
    ANALYTIC_LABEL = kAnalyticLabel
    ANALYTIC_DESCRIPTION_SHORT = kAnalyticDescriptionShort

    #======================================================================
    def __get_event_timing(self, events):
        """
        Use the profiler data to extract the timing taken by a named event.
        If more than one event of the given name exists only the first one
        will be used. Accepts a list so that multiple events can be extracted
        from the same file, only generating the file once.

        :param events: List of event names for which to extract timing

        :return: a dictionary where
            key = Name of event
            value = Time, in microseconds, taken by each event.
                    If the event wasn't found the timing is 0.0.
        """
        self.debug( 'Getting event timing for {}'.format(events) )
        event_times = {}
        try:
            tmp_dir = cmds.internalVar(userTmpDir=True)
            tmp_file = os.path.join( tmp_dir, '__PROFILER__.txt' )
            cmds.profiler( output=tmp_file )
            profiler_data = open( tmp_file, 'r' ).readlines()
            os.remove( tmp_file )
        except Exception, ex:
            self.error( 'Failed to get temp file for profiler data: {}'.format(ex) )
            return

        for event in events:
            event_time = 0
            try:
                re_event = re.compile( r'^(@[0-9]+)\s+=\s+{}$'.format(event) )
                found_event = None
                for line in profiler_data:
                    if found_event is not None:
                        fields = line.split('\t')
                        if len(fields) > 4 and fields[1] == found_event:
                            self.debug( 'Found the timing' )
                            event_time = int(fields[4])
                            # For now take the first occurrence of the event.
                            # It may make sense to use a median, average, or the last one too.
                            break
                    else:
                        match = re_event.match(line)
                        if match:
                            self.debug( 'Found the event' )
                            found_event = match.group(1)
            except Exception, ex:
                self.debug( 'Failed to get timing of event {}, assuming 0: {}'.format(event, ex) )
                event_time = 0
            event_times[event] = event_times.get( event, 0 ) + event_time

        return event_times

    #======================================================================
    @staticmethod
    def __count_clusters(evaluator_list):
        '''
        Check number and membership of clusters currently active in the
        scheduling graph.

        :param evaluator_list: Evaluators to include in the count.
        :return: (NUMBER_OF_CLUSTERS, NUMBER_OF_NODES_IN_CLUSTERS)
                 Counts are the totals for all evaluators in the list
        '''
        cluster_count = 0
        clustered_node_count = 0
        for evaluator in evaluator_list:
            cluster_info = cmds.evaluator( name=evaluator, query=True, clusters=True )
            cluster_idx = 0
            while cluster_idx < len(cluster_info):
                node_count = int(cluster_info[cluster_idx])
                cluster_idx += 1 + node_count
                clustered_node_count += node_count
                cluster_count += 1

        return (cluster_count, clustered_node_count)

    #======================================================================
    @staticmethod
    def __count_cycles():
        '''
        Check number and membership of cycle clusters currently active in the
        scheduling graph.

        :return: (NUMBER_OF_CLUSTERS, NUMBER_OF_NODES_IN_CLUSTERS)
        '''
        # Unfortunately the list of cycles is not readily available so we
        # have to extract the scheduling data and infer the cycle clusters
        # from that.
        cycle_count = 0
        cycle_node_count = 0
        try:
            scheduling_data = json.loads( cmds.dbpeek( op='graph', eg=True, all=True, a='scheduling' ) )['scheduling']['Clusters']
            for (cluster_name, cluster_contents) in scheduling_data.iteritems():
                if cluster_name.find('CycleLayer') >= 0:
                    cycle_count += 1
                    cycle_node_count += len(cluster_contents)
        except Exception:
            # No data, just return zeroes
            pass

        return (cycle_count, cycle_node_count)

    #======================================================================
    def run(self):
        """
        Run the analytic on the current scene.
        :return: JSON results as described in the class doc
        """
        node_data = {}

        vp1_events = ['Vp1PreRefresh'
                     ,'Vp1PreTraversal'
                     ,'Vp1TraverseView'
                     ,'Vp1RefreshTraversal'
                     ,'Vp1RefreshTraversal'
                     ,'Vp1PostTraversal'
                     ,'Vp1PostRefresh'
                     ]
        vp2_events = ['Vp2SceneRender']
        em_events =  ['EvaluationGraphConstruction'
                     ,'EvaluationGraphPartitioning'
                     ,'EvaluationGraphExecution'
                     ]
        inv_events = ['InvisibilityDiscover'
                     ,'InvisibilityCreateClusters'
                     ,'InvisibilityMarkNodes'
                     ,'InvisibilityCreatePartitioning'
                     ]

        try:
            # Measure statistics for each mode by extracting events from the profiler data
            for mode in MODE_LIST:
                node_data[mode] = {}

                with emModeManager() as em_manager:

                    # Ensure the static curves are discovered so that
                    # the EM construction is consistent.
                    em_manager.setMode( 'dg' )
                    cmds.currentTime( cmds.currentTime( query=True )-1 )

                    # Switch to the test mode
                    em_manager.setMode( mode )

                    # Rebuild the graph, then extract the event timing from it.
                    self.debug( 'Profiling normal rebuild' )
                    cmds.profiler( sampling=True )
                    em_manager.rebuild( include_scheduling=True )
                    cmds.profiler( sampling=False )

                    results = self.__get_event_timing( vp1_events + vp2_events + em_events + inv_events )
                    self.debug( 'Got the sample times of {}'.format( results ) )

                    for event in em_events + inv_events:
                        node_data[mode][event] = results[event]

                    # Either VP1 or VP2 will have some timing; just report one
                    vp2_total = 0
                    for event in vp2_events:
                        vp2_total += results[event]

                    if vp2_total > 0:
                        node_data[mode]['Vp2SceneRender'] = vp2_total
                    else:
                        vp1_total = 0
                        for event in vp1_events:
                            vp1_total += results[event]
                        node_data[mode]['Vp1SceneRender'] = vp1_total

                    if not cmds.evaluationManager( query=True, enabled=True ):
                        node_data['Warning'] = 'Evaluation manager was disabled. Timing is not complete'

                    (node_data[mode]['InvisibilityClusterCount'], node_data[mode]['InvisibilityClusterNodeCount']) = self.__count_clusters( ['invisibility'] )
                    (node_data[mode]['ClusterCount'], node_data[mode]['ClusterNodeCount']) = self.__count_clusters( cmds.evaluator(en=True,query=True) )

            # Now measure the file-new time using the external timer
            start_time = cmds.timerX()
            cmds.file( force=True, new=True )
            node_data['FileNew'] = cmds.timerX( startTime=start_time )
            (node_data['CycleCount'], node_data['CycleNodeCount']) = self.__count_cycles()

            self.debug( 'Got the new time of {}'.format( node_data['FileNew'] ) )

        except Exception, ex:
            # If there is no animation there will be no evaluation graph
            self.warning( 'No Evaluation Manager information available ({})'.format(ex) )

        return node_data

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
