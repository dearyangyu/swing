import maya

maya.stringTable['y_analyticUnitConversion.kAnalyticLabel'] = u'UnitConversion'
maya.stringTable['y_analyticUnitConversion.kAnalyticDescriptionShort'] = u'Scene stats collection for the types of connections requiring the use of unit conversion nodes.'

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
