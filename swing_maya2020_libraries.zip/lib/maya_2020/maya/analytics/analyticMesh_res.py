import maya

maya.stringTable['y_analyticMesh.kAnalyticDescriptionShort'] = u'Analytic class for examining mesh objects.'
maya.stringTable['y_analyticMesh.kAnalyticLabel'] = u'Mesh'

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
