import maya

maya.stringTable['y_analyticDeformers.kAnalyticLabel'] = u'Deformers'
maya.stringTable['y_analyticDeformers.kAnalyticDescriptionShort'] = u'Analyze type and usage of single deformers and deformer chains.'

# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
