import maya
maya.utils.loadStringResourcesForModule(__name__)

from maya.app.general.mayaMixin import MayaQWidgetDockableMixin
from maya.app.general.mayaMixin import MayaQWidgetBaseMixin

import maya.api.OpenMaya as OpenMaya
import maya.OpenMayaUI as OpenMayaUI
import maya.cmds as cmds
import maya.mel as mel

from shiboken2 import getCppPointer
import weakref
from functools import partial

from PySide2.QtCore import QEvent, QMimeData, QModelIndex, QObject, QPersistentModelIndex, QSize, Qt, QPoint, QItemSelectionModel, QThread, Signal, Slot
from PySide2.QtGui import QCursor, QDrag, QIcon, QPen, QColor, QPainter, QKeySequence
from PySide2.QtWidgets import QApplication, QMainWindow, QHBoxLayout, QVBoxLayout, QBoxLayout, QGroupBox, QPushButton, QLabel, QFrame, QMenu, QMenuBar, QSizePolicy, QToolTip
from PySide2.QtWidgets import QWidget, QLayoutItem, QAbstractItemView, QTreeView

from maya.app.renderSetup.views.renderSetupButton import RenderSetupButton
from maya.app.renderSetup.views.renderSetupStyle import RenderSetupStyle

from maya.app.renderSetup.views.propertyEditor.layout import Layout
import maya.app.renderSetup.model.plug as plug
import maya.app.renderSetup.views.utils as utils
import maya.app.renderSetup.views.pySide.action as action
import maya.app.renderSetup.views.pySide.menu as menu
import maya.app.renderSetup.views.proxy.renderSetupRoles as renderSetupRoles
import maya.app.renderSetup.views.proxy.renderSetup as rsProxy
import maya.app.renderSetup.views.propertyEditor.main as propertyEditor

import maya.app.renderSetup.model.renderSetup as renderSetup
import maya.app.renderSetup.model.undo as undo
import maya.app.renderSetup.model.utils as modelUtils
import maya.app.renderSetup.model.sceneObservable as sceneObservable
import maya.app.renderSetup.common.errorAndWarningDeferrer as errorAndWarningDeferrer

import maya.app.renderSetup.lightEditor.model.editor as editorModel
import maya.app.renderSetup.lightEditor.model.item as itemModel
import maya.app.renderSetup.lightEditor.model.light as lightModel
import maya.app.renderSetup.lightEditor.model.group as groupModel
import maya.app.renderSetup.lightEditor.model.typeManager as typeMgr
import maya.app.renderSetup.lightEditor.model.update as updateModel
import maya.app.renderSetup.lightEditor.views.proxy as proxy
from maya.app.renderSetup.lightEditor.views.delegate import LightEditorDelegate


kLightEditorTitle     = maya.stringTable['y_editorUI.kLightEditorTitle'     ]
kHelp                 = maya.stringTable['y_editorUI.kHelp'                 ]
kMayaHelp             = maya.stringTable['y_editorUI.kMayaHelp'             ]
kLightEditorHelp      = maya.stringTable['y_editorUI.kLightEditorHelp'      ]
kLayerText            = maya.stringTable['y_editorUI.kLayerText'            ]
kDefaultLayerText     = maya.stringTable['y_editorUI.kDefaultLayerText'     ]

kLookThroughLightsToolTip = maya.stringTable['y_editorUI.kLookThroughLightsToolTip' ]
kSnapToSelectedToolTip    = maya.stringTable['y_editorUI.kSnapToSelectedToolTip'    ]
kPropertyEditorToolTip    = maya.stringTable['y_editorUI.kPropertyEditorToolTip'    ]

class LightEditorView(QTreeView):
    """
    This class implements the light editor view.
    """

    # NO_LIGHTS_IMAGE = utils.createPixmap(_NOL10N(":/RS_no_light.png"))
    PLACEHOLDER_TEXT_PEN = QPen(QColor(128, 128, 128))
    HALF_FONT_HEIGHT = utils.dpiScale(7)
    NO_LIGHTS_IMAGE_SIZE = utils.dpiScale(62)

    def __init__(self, parent):
        super(LightEditorView, self).__init__(parent=parent)
        self.actionButtonPressed = False
        self.setIndentation(10)

        self.setMouseTracking(True)

        # Set up the Qt Model
        self.localModelRef = proxy.LightEditorProxy(self)
        self.setModel(self.localModelRef)

        self.setHeaderHidden(True)
        self.setItemDelegate(LightEditorDelegate(self))
        self.setStyle(RenderSetupStyle(self.style()))
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        selectionModel = self.selectionModel()
        selectionModel.selectionChanged.connect(self._selectionChanged)
        self.trackSelection = True

        # Right click context
        self.contextMenu = menu.Menu(self)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showContextMenu)

        # Right click potential actions
        self.expandCollapseAction = action.Action(rsProxy.EXPAND_COLLAPSE_ACTION, self.contextMenu, triggered=self._toggleExpandCollapse)
        self.setEnabledAction = action.Action(rsProxy.SET_ENABLED_ACTION, self.contextMenu, triggered=self._setEnabled)
        self.isolateSelectAction = action.Action(rsProxy.SET_ISOLATE_SELECTED_ACTION, self.contextMenu, triggered=self._setIsolateSelected)
        self.renameAction = action.Action(rsProxy.RENAME_ACTION, self.contextMenu, triggered=self._rename)
        self.deleteAction = action.Action(rsProxy.DELETE_ACTION, self.contextMenu, triggered=self._delete)

        # staticActions are a list of potential actions proposed in the
        # context menu.  Illegal actions are filtered out in
        # showContextMenu() by querying the proxy items.
        self.staticActions = [ self.expandCollapseAction,
                               self.setEnabledAction,
                               self.isolateSelectAction,
                               self.renameAction,
                               self.deleteAction]

        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDefaultDropAction(Qt.MoveAction)

        self.installEventFilter(self)

        # Restore all expanded nodes, beginning from the Model Ref
        self._restoreExpandedState(self.localModelRef)

    def rowsInserted(self, parent, start, end):
        super(LightEditorView, self).rowsInserted(parent, start, end)
        index = QModelIndex(parent)
        while(index.isValid()):
            self.setExpanded(index, True)
            index = index.parent()

    def setExpanded(self, index, state):
        """ Override from the Qt class
        Expands the group and saves its state """
        super(LightEditorView, self).setExpanded(index, state)
        utils.setExpandedState(self._getCorrespondingItem(index)._model.thisMObject(), state)

    def aboutToDelete(self):
        self.localModelRef.dispose()

    def refreshView(self):
        for i in range(self.model().rowCount()):
            item = self.model().child(i,0)
            item.model.itemChanged()

    def mousePressEvent(self, event):
        wasRightButton = event.button() == Qt.RightButton
        event = utils.updateMouseEvent(event)
        if event.button() == Qt.LeftButton:
            if not event.modifiers() & Qt.ShiftModifier:
                index = self.indexAt(event.pos())
                # get the action button under the mouse if there is one
                action = self._getCurrentAction(event.pos(), index)
                if action != None:
                    # set the currently clicked on element active without selecting it
                    self.selectionModel().setCurrentIndex(index, QItemSelectionModel.NoUpdate)
                    # trigger the action to be executed
                    action.trigger()
                    self.actionButtonPressed = True
                    event.accept()
                else:
                    # Select the currently clicked on element
                    super(LightEditorView, self).mousePressEvent(event)
            else:
                super(LightEditorView, self).mousePressEvent(event)

        elif event.button() == Qt.RightButton:
            if not wasRightButton:
                self.customContextMenuRequested.emit(event.pos())

            # if the clicked item is already selected, then right clicking should not change the selection
            index = self.indexAt(event.pos())
            if not self.selectionModel().isSelected(index):
                item = self.model().itemFromIndex(index)
                if item:
                    # Select the currently clicked on element
                    self.setCurrentIndex(index)
            else:
                # Because of the behavior for 'click on action' where the current index is changed
                # but the selection model is not updated accordingly,
                # ensure that the selected item is also the current index
                self.selectionModel().setCurrentIndex(index, QItemSelectionModel.NoUpdate)

        elif event.button() == Qt.MiddleButton:
            super(LightEditorView, self).mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        event = utils.updateMouseEvent(event)
        if not self.actionButtonPressed:
            super(LightEditorView, self).mouseReleaseEvent(event)
        else:
            self.actionButtonPressed = False

    def leaveEvent(self, *args, **kwargs):
        self.itemDelegate().lastHitAction = None

    def mouseMoveEvent(self, event):
        event = utils.updateMouseEvent(event)
        if not self.actionButtonPressed:
            super(LightEditorView, self).mouseMoveEvent(event)

        if not self.itemDelegate().lastHitAction:
            QToolTip.hideText()

        # dirty the treeview so it will repaint when mouse is over it
        # this is needed to change the icons when ohvered over them
        self.itemDelegate().lastHitAction = None
        region = self.childrenRegion()
        self.setDirtyRegion(region)

    def mouseDoubleClickEvent(self, event):
        event = utils.updateMouseEvent(event)
        index = self.indexAt(event.pos())
        item = self.model().itemFromIndex(index)
        action = self._getCurrentAction(event.pos(), index)
        if action != None:
            # trigger the action to be executed
            action.trigger()
        elif item and item.data(renderSetupRoles.NODE_EDITABLE):
            # Put item in edit mode if it is editable
            self.edit(index)

        # Propagate event to item
        if item:
            item.onDoubleClick(self)

    def eventFilter(self, object, event):
        if event.type() == QEvent.KeyPress:
            if event.key() == Qt.Key_Delete:
                self._delete()
                return True
        return super(LightEditorView, self).eventFilter(object, event)

    def paintEvent(self, e):
        """ Overrides the paint event to make it so that place holder text is displayed when the list is empty. """
        super(LightEditorView, self).paintEvent(e)
        if self.model().rowCount() == 0:
            painter = QPainter(self.viewport())
            sz = self.NO_LIGHTS_IMAGE_SIZE
            sz = sz / 2
            pos = self.contentsRect().center() - QPoint(sz, sz+self.HALF_FONT_HEIGHT)
            # painter.drawPixmap(pos, self.NO_LIGHTS_IMAGE)

            oldPen = painter.pen()
            painter.setPen(self.PLACEHOLDER_TEXT_PEN)
            textRect = self.contentsRect()
            textRect.translate(0, sz)
            painter.drawText(textRect, Qt.AlignCenter, maya.stringTable['y_editorUI.kNoLayers' ])
            painter.setPen(oldPen)

    def _getCorrespondingItem(self, index):
        if index.isValid():
            return self.model().itemFromIndex(index)
        return None

    def _createActionSubMenus(self, topMenu, name):
        ''' Add all the submenus computed from the action name '''
        # Find all sub menus (i.e. all parts of the path)
        head, tail = os.path.split(name)
        parts = [tail]
        while head!='':
            head, tail = os.path.split(head)
            parts.insert(0, tail)
        # If there is a path in the action name then create or reuse the sub menus
        currentMenu = topMenu
        for idx in range(len(parts)-1):
            existingSubMenus = currentMenu.findChildren(QMenu)
            for o in existingSubMenus:
                if o.title()==parts[idx]:
                    currentMenu = o
                    break
            else:
                currentMenu = currentMenu.addMenu(parts[idx])
        return (currentMenu, parts[-1])

    def showContextMenu(self, point):
        ''' Rebuild from scratch the context menu '''
        selectedIndexes = self.selectedIndexes()
        numIndexes = len(selectedIndexes)
        # Only show the context menu if we have selected items
        if numIndexes > 0:
            # Make a list of all actions and remove all actions that don't apply to each element
            applicableStaticActions = list(self.staticActions)
            for selectedIndex in selectedIndexes:
                actionsToRemove = []
                for action in applicableStaticActions:
                    item = self._getCorrespondingItem(selectedIndex)
                    if not item.supportsAction(action.text(), numIndexes):
                        actionsToRemove.append(action)
                for actionToRemove in actionsToRemove:
                    applicableStaticActions.remove(actionToRemove)

            # Note: Directly clear() the QMenu causes 'already deleted exception'
            #       so I manually remove the actions
            for a in reversed(self.contextMenu.actions()):
                self.contextMenu.removeAction(a)

            # Add the static menus to the context menu
            self.contextMenu.addActions(applicableStaticActions)

            self.contextMenu.exec_(self.mapToGlobal(point))

    def _rename(self):
        """ Begins editing of the current tree view index. """
        self.edit(self.currentIndex())

    def _getCurrentAction(self, point, index):
        item = self.model().itemFromIndex(index)
        if item:
            # If the row has children, check to see if the user clicked before the row entry name. If so, then expand/collapse the row
            if item.rowCount() > 0:
                leftOffset = 0
                indent = item.depth() * self.indentation()
                leftOffset = indent + LightEditorDelegate.LEFT_NON_TEXT_OFFSET
                if point.x() < leftOffset:
                    return self.expandCollapseAction

            actionName = self.itemDelegate().lastHitAction
            if actionName != None:
                for a in self.staticActions:
                    if a.text() == actionName:
                        return a
            return None
        return None

    def _setState(self, flag, state, item = None):
        if item == None:
            item = self._getCorrespondingItem(self.currentIndex())
        if item:
            if not self.selectionModel().isSelected(self.currentIndex()):
                # only toggle the current item if it's not selected
                item.setData(state, flag)
            else:
                # else set all selected items to the same state
                selectedIndexes = self.selectedIndexes()
                for selectedIndex in selectedIndexes:
                    selItem = self._getCorrespondingItem(selectedIndex)
                    if selItem:
                        selItem.setData(state, flag)

        # invalidate the view for full redraw.
        # MAYA-66676: It is unclear why this is needed, we should look into removing this
        region = self.childrenRegion()
        self.setDirtyRegion(region)

    def _toggleState(self, flag):
        item = self._getCorrespondingItem(self.currentIndex())
        if item:
            state = not item.data(flag)
            self._setState(flag, state, item)

    def _toggleExpandCollapse(self):
        index = self.currentIndex()
        self.setExpanded(index, not self.isExpanded(index))

    def _setEnabled(self):
        self._toggleState(renderSetupRoles.NODE_SELF_ENABLED)

    def _setIsolateSelected(self):
        self._toggleState(renderSetupRoles.NODE_ISOLATE_SELECTED)

    @undo.chunk('Delete items')
    def _deleteItems(self, indexes):
        for index in indexes:
            item = self._getCorrespondingItem(index)
            if item:
                item.delete()

    def _delete(self):
        selectedIndexes = self.selectedIndexes()
        if len(selectedIndexes) < 1:
            return
        persistentSelectedIndexes = []
        for selectedIndex in selectedIndexes:
            persistentSelectedIndexes.append(QPersistentModelIndex(selectedIndex))
        self._deleteItems(persistentSelectedIndexes)

    def _restoreExpandedState(self, proxy):
        """ Recursively get all proxies of the treeview
        and expand them if they were already expanded before closing the
        window, and do the same on their children.
        It stops because overrides do not have children
        (and if they have children, it will still work) """

        proxies = []
        for i in range(proxy.rowCount()):
            proxies.append(proxy.child(i,0))

        for child in proxies:
            if utils.getExpandedState(child._model.thisMObject()):
                self.setExpanded(child.index(), True)
                self._restoreExpandedState(child)

    def _selectionChanged(self, selected, deselected):
        """ Callback for selection changes """
        if not self.trackSelection:
            return

        selectionModel = self.selectionModel()
        selection = selectionModel.selectedIndexes()

        names = []
        for i in range(0, len(selection)):
            item = self.model().itemFromIndex(selection[i])
            if item.typeIdx() == proxy.LIGHT_ITEM_TYPE_IDX:
                names.append(item.model.getLightName(fullPath = True))
            else:
                names.append(item.model.name())

        self.trackSelection = False

        if len(names) > 0:
            cmds.select(names, add=False, noExpand=True)
        else:
            cmds.select(clear=True)

        self.trackSelection = True

        self.parent().selectionChanged()


class LookThroughWindow(MayaQWidgetDockableMixin, QWidget):
    """ This class implements the look through window. """

    # Constants
    STARTING_SIZE = QSize(utils.dpiScale(300), utils.dpiScale(300))
    PREFERRED_SIZE = STARTING_SIZE
    MINIMUM_SIZE = QSize(100, 100)

    def __init__(self):
        super(LookThroughWindow, self).__init__(parent=None)
        self.preferredSize = self.PREFERRED_SIZE
        self.resize(self.STARTING_SIZE)
        self.panel = None

        self.setObjectName('MayaLightLookThroughWindow')

        layout = QVBoxLayout()
        layout.setObjectName('LookThroughWindowVerticalBoxLayout')
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(utils.dpiScale(2))
        self.setLayout(layout)

        # Get the layout name and set as parent
        layoutName = OpenMayaUI.MQtUtil.fullName(long(getCppPointer(layout)[0]))
        oldParent = cmds.setParent(query=True)
        cmds.setParent(layoutName)

        # Create (or reuse) a model panel
        lookThroughPanelLabel = "lightEditorLookThroughModelPanelLabel"
        previousLookThroughPanel = cmds.getPanel(withLabel=lookThroughPanelLabel)
        if previousLookThroughPanel != None:
            self.panel = previousLookThroughPanel
            cmds.modelPanel(self.panel, edit=True, parent=self.objectName())
        else :
            self.panel = cmds.modelPanel()
            cmds.modelPanel(self.panel, edit=True, label=lookThroughPanelLabel)

        # Enable smooth shading
        editor = cmds.modelPanel(self.panel, query=True, modelEditor=True)
        cmds.modelEditor(editor, edit=True, displayAppearance="smoothShaded")

        cmds.setParent(oldParent)

    def aboutToDelete(self):
        pass

    def setSizeHint(self, size):
        self.preferredSize = size

    def sizeHint(self):
        return self.preferredSize

    def minimumSizeHint(self):
        return self.MINIMUM_SIZE

    def lookThroughLight(self, light):
        """ Opens a model panel with camera looking through the given light. """
        if light and self.panel:
            self.setWindowTitle(maya.stringTable['y_editorUI.kLookingThrough'] + light)
            cmd = "lookThroughModelPanelClipped(\"" + light + "\", \"" + self.panel + "\", 0.001, 1000)"
            mel.eval(cmd)
        else:
            self.setWindowTitle(maya.stringTable['y_editorUI.kSelectTheLight'])


class LightEditorCentralWidget(QWidget):
    """
    This class implements the controls inside the light editor window
    """

    PREFERRED_SIZE = QSize(370, 420)
    MINIMUM_SIZE = QSize(220, 220)
    BUTTON_SIZE = utils.dpiScale(20)

    def __init__(self, parent):
        # The class MayaQWidgetDockableMixin retrieves the right parent (i.e. Maya Main Window)
        super(LightEditorCentralWidget, self).__init__(parent=parent)

        self.sceneIsLoading = 0
        self.selectedParent = None

        typeMgr.rebuild()

        # Set up the menu bar
        self.menuBar = QMenuBar(self)
        self.helpMenu = self.menuBar.addMenu(kHelp)
        self.mayaHelp = action.Action(kMayaHelp, self.helpMenu)
        self.lightEditorHelp = action.Action(kLightEditorHelp, self.helpMenu)
        self.mayaHelp.triggered.connect(lambda: maya.mel.eval("showHelp -d index.html"))
        self.lightEditorHelp.triggered.connect(lambda: maya.mel.eval("showHelp LightEditor"))
        self.helpMenu.addAction(self.mayaHelp)
        self.helpMenu.addAction(self.lightEditorHelp)

        self.lightEditorView = LightEditorView(self)

        # Adds the tree view to the window's layouts
        # the lightEditorView is set to be stretchy, while the other widgets are not
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(5)
        layout.addWidget(self.menuBar, 0)
        layout.addSpacing(10)

        layout.addWidget(self._createToolBar(), 0)

        hline = QFrame()
        hline.setFrameStyle(QFrame.HLine | QFrame.Plain)
        hline.setLineWidth(1)
        layout.addWidget(hline)

        layout.addWidget(self._createLabels(), 0)
        layout.addWidget(self.lightEditorView, 1)

        self.setLayout(layout)

        self.setAcceptDrops(True)

        self._callbackIds = [
            OpenMaya.MEventMessage.addEventCallback("SelectionChanged", self._onDgSelectionChangedCB),

            # Notification of scene changes before and after new/open/import.
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeNew, self._onBeforeSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterNew, self._onAfterSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeOpen, self._onBeforeSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterOpen, self._onAfterSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeImport, self._onBeforeSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterImport, self._onAfterSceneChangeCB),

            # Notification of scene changes before and after create/load reference.
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeCreateReference, self._onBeforeSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterCreateReferenceAndRecordEdits, self._onAfterSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeLoadReference, self._onBeforeSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterLoadReferenceAndRecordEdits, self._onAfterSceneChangeCB),

            # Notification of scene changes before and after remove/unload reference.
            # Before unloading we need to handled correct deletions and reordering
            # of light editor items.
            OpenMaya.MSceneMessage.addReferenceCallback(OpenMaya.MSceneMessage.kBeforeRemoveReference, self._onBeforeUnloadReferenceCB),
            OpenMaya.MSceneMessage.addReferenceCallback(OpenMaya.MSceneMessage.kBeforeUnloadReference, self._onBeforeUnloadReferenceCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterUnloadReference, self._onAfterSceneChangeCB),
            OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterRemoveReference, self._onAfterSceneChangeCB),

            # Notification of light sources added or connections to light items changed
            OpenMaya.MDGMessage.addNodeAddedCallback(self._onMayaNodeAddedCB, "dependNode"),
            OpenMaya.MDGMessage.addConnectionCallback(self._onMayaConnectionCB),

            # We need to track changes to Color Management since we handle color management for light source colors ourself
            OpenMaya.MEventMessage.addEventCallback("colorMgtEnabledChanged", self._onColorMgtChangedCB),
            OpenMaya.MEventMessage.addEventCallback("colorMgtConfigChanged", self._onColorMgtChangedCB),
            OpenMaya.MEventMessage.addEventCallback("colorMgtWorkingSpaceChanged", self._onColorMgtChangedCB),
            OpenMaya.MEventMessage.addEventCallback("colorMgtPrefsViewTransformChanged", self._onColorMgtChangedCB),
            OpenMaya.MEventMessage.addEventCallback("colorMgtPrefsReloaded", self._onColorMgtChangedCB),
            OpenMaya.MEventMessage.addEventCallback("colorMgtUserPrefsChanged", self._onColorMgtChangedCB)
        ]

        # Listen for render setup add/remove and render layer changes
        self._layerObserverAdded = False
        renderSetup.addObserver(self)
        self._addLayerObserver()

    def aboutToDelete(self):
        """Cleanup method to be called immediately before the object is deleted."""
        OpenMaya.MMessage.removeCallbacks(self._callbackIds)
        self._callbackIds = []

        self._removeLayerObserver()
        renderSetup.removeObserver(self)

        if self.lightEditorView:
            self.lightEditorView.aboutToDelete()
            self.lightEditorView = None

    def renderSetupAdded(self):
        self._addLayerObserver()

    def renderSetupPreDelete(self):
        self._removeLayerObserver()

    def _addLayerObserver(self):
        if renderSetup.hasInstance() and not self._layerObserverAdded:
            renderSetup.instance().addActiveLayerObserver(self._onRenderLayerChangeCB)
            self._layerObserverAdded = True

    def _removeLayerObserver(self):
        if renderSetup.hasInstance() and self._layerObserverAdded:
            renderSetup.instance().removeActiveLayerObserver(self._onRenderLayerChangeCB)
            self._layerObserverAdded = False

    def _onRenderLayerChangeCB(self):
        # Update the layer indicator
        text = kLayerText + kDefaultLayerText
        if renderSetup.hasInstance():
            visibleRenderLayer = renderSetup.instance().getVisibleRenderLayer()
            defaultRenderLayer = renderSetup.instance().getDefaultRenderLayer()
            if visibleRenderLayer != defaultRenderLayer:
                text = kLayerText + visibleRenderLayer.name()
        self.layerText.setText(text)

        # Make sure the light editor model gets updated for the new layer
        updateModel.doUpdate()

    def sizeHint(self):
        return self.PREFERRED_SIZE

    def minimumSizeHint(self):
        return self.MINIMUM_SIZE

    def _createToolBar(self):

        mayaLightButtons = []
        pluginLightButtons = []

        mayaLights = typeMgr.mayaLights()
        for lightType in mayaLights:
            if typeMgr.excludeFromUI(lightType):
                continue
            icon = utils.createIcon( typeMgr.getIcon(lightType) )
            button = RenderSetupButton(self, icon, self.BUTTON_SIZE)
            button.clicked.connect( self.getLightCreator(lightType) )
            toolTip = maya.stringTable['y_editorUI.kCreateaNew1' ] + lightType
            button.setToolTip(toolTip)
            mayaLightButtons.append(button)

        pluginLights = typeMgr.pluginLights()
        for lightType in pluginLights:
            icon = utils.createIcon( typeMgr.getIcon(lightType) )
            button = RenderSetupButton(self, icon, self.BUTTON_SIZE)
            button.clicked.connect( self.getLightCreator(lightType) )
            toolTip = maya.stringTable['y_editorUI.kCreateaNew2' ] + lightType
            button.setToolTip(toolTip)
            pluginLightButtons.append(button)

        leftToolbarWidget = QWidget()
        leftToolbarLayout = QHBoxLayout()
        QLayoutItem.setAlignment(leftToolbarLayout, Qt.AlignBottom)
        leftToolbarLayout.setContentsMargins(0, 0, 0, 0)
        leftToolbarLayout.addStretch(1)
        leftToolbarLayout.setDirection(QBoxLayout.RightToLeft)

        self.layerText = QLabel(kLayerText)
        leftToolbarLayout.addWidget(self.layerText)
        leftToolbarLayout.addWidget( QLabel(" | ") )

        button = QPushButton(maya.stringTable['y_editorUI.kNewGroup2'])
        button.clicked.connect(self.newGroup)
        button.setToolTip(maya.stringTable['y_editorUI.kCreateaNewGroup' ])
        leftToolbarLayout.addWidget(button)
        leftToolbarLayout.addWidget( QLabel(" | ") )

        if len(pluginLightButtons):
            for btn in reversed(pluginLightButtons):
                leftToolbarLayout.addWidget(btn)
            leftToolbarLayout.addWidget( QLabel(" | ") )
        for btn in reversed(mayaLightButtons):
            leftToolbarLayout.addWidget(btn)

        leftToolbarWidget.setLayout(leftToolbarLayout)

        rightToolbarWidget = QWidget()
        rightToolbarLayout = QHBoxLayout()
        QLayoutItem.setAlignment(rightToolbarLayout, Qt.AlignBottom)
        rightToolbarLayout.setContentsMargins(0, 0, 0, 0)
        rightToolbarLayout.addStretch(1)
        rightToolbarLayout.setDirection(QBoxLayout.LeftToRight)

        icon = utils.createIcon(":/LM_LookThroughLights.png")
        button = RenderSetupButton(self, icon, self.BUTTON_SIZE)
        button.setToolTip(kLookThroughLightsToolTip)
        button.clicked.connect(createLookThroughWindow)
        rightToolbarLayout.addWidget(button)

        icon = utils.createIcon(":/LM_snap_toGeo.png")
        button = RenderSetupButton(self, icon, self.BUTTON_SIZE)
        button.setToolTip(kSnapToSelectedToolTip)
        button.clicked.connect(self._snapToSelected)
        rightToolbarLayout.addWidget(button)

        icon = utils.createIcon(":/attributes.png")
        button = RenderSetupButton(self, icon, self.BUTTON_SIZE)
        button.setToolTip(kPropertyEditorToolTip)
        button.clicked.connect(createPropertyEditorWindow)
        rightToolbarLayout.addWidget(button)

        rightToolbarWidget.setLayout(rightToolbarLayout)

        toolbarWidget = QWidget()
        layout = QHBoxLayout()
        layout.setContentsMargins(utils.dpiScale(5), 0, utils.dpiScale(5), 0)

        layout.addWidget(leftToolbarWidget)
        layout.addWidget(rightToolbarWidget)
        toolbarWidget.setLayout(layout)

        # Update the layer indicator
        self._onRenderLayerChangeCB()

        return toolbarWidget

    def _createLabels(self):

        labelsWidget = QWidget()
        layout = QHBoxLayout()
        layout.setContentsMargins(utils.dpiScale(5), 0, utils.dpiScale(5), 0)

        rightWidget = QWidget()

        rightLayout = QHBoxLayout()
        QLayoutItem.setAlignment(rightLayout, Qt.AlignBottom)
        rightLayout.setContentsMargins(0, 0, 0, 0)
        rightLayout.setDirection(QBoxLayout.LeftToRight)

        label = QLabel()
        label.setText(maya.stringTable['y_editorUI.kName' ])
        label.setMinimumWidth(utils.dpiScale(180))
        rightLayout.addWidget(label)

        lightAttributes = typeMgr.getAllAttributes()
        for attrLabel, dataType in lightAttributes.items():
            label = QLabel()
            label.setText(attrLabel)
            label.setMinimumWidth(utils.dpiScale(85))
            rightLayout.addWidget(label)

        rightLayout.addStretch(1)
        rightWidget.setLayout(rightLayout)

        layout.addWidget(rightWidget)
        labelsWidget.setLayout(layout)

        return labelsWidget

    def getLightCreator(self, lightType):
        def _lightCreator():
            self.newLight(lightType)
        return _lightCreator

    @undo.chunk("Create light group")
    def newGroup(self):
        """ Create a new light group in the selected parent. """
        group = editorModel.instance().createGroupItem(self._findSelectedParent())
        cmds.select(group.name())

    @undo.chunk("Create light source")
    def newLight(self, lightType):
        """ Create a new light source. """

        # We must save the selected parent before creating the
        # light source since that will modify the selection.
        # Adding a light item to this parent is handled by
        # _onMayaNodeAddedCB() below
        self.selectedParent = self._findSelectedParent()

        cmd = typeMgr.getCreateCmd(lightType)
        if cmd and len(cmd) > 0:
            mel.eval(cmd)
        else:
            cmds.shadingNode(lightType, asLight=True, name="%sShape1" % lightType)

        # Reset selected parent again
        self.selectedParent = None

    def _findSelectedParent(self):
        selectionList = OpenMaya.MGlobal.getActiveSelectionList()
        for i in range(selectionList.length()):
            obj = selectionList.getDependNode(i)
            fn = OpenMaya.MFnDependencyNode(obj)

            if isinstance(fn.userNode(), groupModel.LightGroup):
                # A light group so return it
                return fn.userNode()

            if isinstance(fn.userNode(), lightModel.LightItem):
                # A light item so return its parent group
                return fn.userNode().parent()

            # Find connected light item and return its parent group
            item = editorModel.instance().findEditorItem(obj)
            if item:
                return item.parent()

        return None

    def _onBeforeSceneChangeCB(self, *args, **kwargs):
        # Callback paired with _onAfterSceneChangeCB, handling scene updates.
        # These callbacks support nested calls and will only trigger a single
        # model update for multiple nested calls, using a counter.
        # This could happen with referencing where one or several of the
        # before/after callback pairs are triggered depending on if a
        # reference is created, loaded, unloaded or removed.
        self.sceneIsLoading += 1
        if self.sceneIsLoading == 1:
            self.lightEditorView.model().resetModel()

    def _onAfterSceneChangeCB(self, *args, **kwargs):
        # See docstring for sibling callback _onBeforeSceneChangeCB above.
        if self.sceneIsLoading == 1:
            editorModel.instance().rebuildScene()
            self.lightEditorView.model().refreshModel()
        self.sceneIsLoading -= 1

    def _onBeforeUnloadReferenceCB(self, referenceNode, resolvedRefPath, clientData):

        # Trigger the before scene change callback to make the
        # scene update correctly after this change.
        self._onBeforeSceneChangeCB()

        # Find any light items attached to the nodes that are unloading
        # and delete these items. We don't want rogue items in the scene,
        # and we need to detach and delete them properly to keep the light
        # editor tree ordering.
        #
        # TODO: This will not preserve item ordering for these referenced lights
        # if the reference is loaded in again later. It's not a major issues,
        # but we could try to improve on that in a future update.
        #
        if editorModel.hasInstance():
            editor = editorModel.instance()
            fnRef = OpenMaya.MFnReference(referenceNode)
            for node in fnRef.nodes():
                # Find the corresponding item and delete it
                item = editor.findEditorItem(node)
                if item:
                    itemModel.deleteItem(item, deleteLight=False)

    @modelUtils.notUndoRedoing
    def _onMayaNodeAddedCB(self, obj, clientData):
        # Ignore node additions during scene load and undo/redo
        # The editor is filled after loading is completed
        if self.sceneIsLoading:
            return

        # If a light source is added we create a light editor item for it
        if typeMgr.isValidLightShapeObject(obj) and not editorModel.instance().findEditorItem(obj):
            # Create a new light item in the selected parent
            editorModel.instance().createLightItem(obj, self.selectedParent)

    def _onMayaConnectionCB(self, srcPlug, dstPlug, made, clientData):
        # Ignore connections during scene load
        # The editor is filled after loading is completed
        if self.sceneIsLoading:
            return

        # Check if this was a light connection to a light editor item
        if dstPlug.attribute() == lightModel.LightItem.light:
            fn = OpenMaya.MFnDependencyNode(dstPlug.node())
            lightItem = fn.userNode()
            if made:
                # New connection was made so register the callbacks for the light shape
                lightItem.registerCallbacks(srcPlug.node())
            else:
                # Connection was broken so unregister the callbacks for the light shape
                lightItem.unregisterCallbacks()

    def _onColorMgtChangedCB(self, clientData):
        self.lightEditorView.refreshView()

    def _onDgSelectionChangedCB(self, clientData):

        # Early out if no light editor node exists,
        # or selection tracking is disabled
        if not editorModel.hasInstance() or not self.lightEditorView.trackSelection:
            return

        self.lightEditorView.trackSelection = False

        sm = self.lightEditorView.selectionModel()
        sm.clear()

        indices = []
        selectionList = OpenMaya.MGlobal.getActiveSelectionList()

        for i in range(selectionList.length()):
            # Check if it's a light editor item
            obj = selectionList.getDependNode(i)
            fn = OpenMaya.MFnDependencyNode(obj)
            item = fn.userNode() if isinstance(fn.userNode(), itemModel.LightItemBase) else editorModel.instance().findEditorItem(obj)
            if item:
                p = proxy.getProxy(item)
                if p:
                    indices.append(p.index())

        for index in indices:
            sm.select(index, QItemSelectionModel.Rows | QItemSelectionModel.Select)

        self.selectionChanged()
        self.lightEditorView.trackSelection = True

    def selectionChanged(self):
        lookThroughSelectedLight()

    def _snapToSelected(self):
        sit = OpenMaya.MItSelectionList(OpenMaya.MGlobal.getActiveSelectionList())
        sit.setFilter(OpenMaya.MItSelectionList.kDagSelectionItem)

        centerDagPath = None
        names = []
        while not sit.isDone():
            dp = sit.getDagPath()
            sit.next()
            if sit.isDone():
                centerDagPath = dp
            else:
                names.append(dp.fullPathName())

        if len(names) == 0:
            OpenMaya.MGlobal.displayInfo(maya.stringTable['y_editorUI.kSnapToObjectNothingSelected'])
            return

        # NOTE: We use the exclusive matrix since the bounding box is partially transformed
        #       The bbox does not take parent transforms into account though
        mtx = centerDagPath.exclusiveMatrix()
        centerNode = centerDagPath.node()
        dagFN = OpenMaya.MFnDagNode(centerNode)
        pos = dagFN.boundingBox.center * mtx

        cmds.move(pos[0],pos[1],pos[2], names, absolute=True, worldSpaceDistance=True)


class LightEditorWindow(MayaQWidgetDockableMixin, QWidget):
    """
    This class implements the dockable light editor window.
    """

    # Constants
    # MAYA-66674: Make default size a user preference
    # width = (cmds.optionVar(query=_NOL10N('workspacesWidePanelInitialWidth'))) * 0.25
    width = 600
    STARTING_SIZE = QSize(width, 600)
    PREFERRED_SIZE = QSize(width, 420)
    MINIMUM_SIZE = QSize((width * 0.95), 220)

    def __init__(self):
        # The class MayaQWidgetDockableMixin retrieves the right parent (i.e. Maya Main Window)
        super(LightEditorWindow, self).__init__(parent=None)
        self.preferredSize = self.PREFERRED_SIZE

        self.setWindowTitle(kLightEditorTitle)
        self.resize(utils.dpiScale(self.STARTING_SIZE))

        # create a frame that other windows can dock into.
        self.dockingFrame = QMainWindow(self)
        self.dockingFrame.layout().setContentsMargins(0,0,0,0)
        self.dockingFrame.setWindowFlags(Qt.Widget)
        self.dockingFrame.setDockOptions(QMainWindow.AnimatedDocks)

        self.centralWidget = LightEditorCentralWidget(self)
        self.centralWidget.layout().setContentsMargins(0,0,0,0)
        self.dockingFrame.setCentralWidget(self.centralWidget)

        # Adds the tree view to the window's layouts
        # the renderSetupView is set to be stretchy, while the other widgets are not
        layout = QVBoxLayout(self)
        layout.addWidget(self.dockingFrame, 0)
        self.setLayout(layout)

        errorAndWarningDeferrer.instance().displayErrorsAndWarnings()

    def setSizeHint(self, size):
        self.preferredSize = size

    def sizeHint(self):
        return self.preferredSize

    def minimumSizeHint(self):
        return self.MINIMUM_SIZE

    def aboutToDelete(self):
        self.centralWidget.aboutToDelete()

    def show(self, *args, **kwargs):
        # Override MayaQWidgetDockableMixin.show() method
        # to resolve menu parenting issues for templates
        # MAYA-73418
        super(LightEditorWindow, self).show(*args, **kwargs)


# Singleton window instances
_lightEditorWindow = None
_propertyEditorWindow = None
_lookThroughWindow = None

def saveWindowState(editor, optionVar):
    windowState = editor.showRepr()
    cmds.optionVar(sv=(optionVar, windowState))

def lightEditorWindowClosed():

    # Close and delete the look through window if it exists
    global _lookThroughWindow
    if _lookThroughWindow:
        _lookThroughWindow.aboutToDelete()
        _lookThroughWindow.windowStateChanged.disconnect(lookThroughWindowChanged)
        _lookThroughWindow.close()
        _lookThroughWindow = None

    # Make sure the property editor window is closed before we close the
    # main light editor window. It holds a reference to the same treeView
    # instance and must be released before it's destroyed by the main window.
    propertyEditorWindowClosed()

    global _lightEditorWindow
    if _lightEditorWindow:
        _lightEditorWindow.aboutToDelete()
        _lightEditorWindow = None

def lightEditorWindowChanged():
    global _lightEditorWindow
    saveWindowState(_lightEditorWindow, 'lightEditorWindowState')

# Sets up the light editor main window
def createLightEditorWindow(restore=False):
    global _lightEditorWindow

    # Make sure the light editor model node is created,
    # as well as all editor item nodes
    editorModel.instance().rebuildScene()

    if restore:
        parent = OpenMayaUI.MQtUtil.getCurrentParent()

    if _lightEditorWindow is None:
        _lightEditorWindow = LightEditorWindow()
        _lightEditorWindow.setObjectName('MayaLightEditorWindow')

        # hook up a callbacks so we know when the window is moved and resized.
        _lightEditorWindow.windowStateChanged.connect(lightEditorWindowChanged)

    if restore:
        mixinPtr = OpenMayaUI.MQtUtil.findControl(_lightEditorWindow.objectName())
        OpenMayaUI.MQtUtil.addWidgetToMayaLayout(long(mixinPtr), long(parent))
    else:
        size = LightEditorWindow.STARTING_SIZE
        minSize = LightEditorWindow.MINIMUM_SIZE
        _lightEditorWindow.show(dockable=True, retain=False, width=size.width(), widthSizingProperty='preferred', minWidth=minSize.width(), height=size.height(), x=250, y=200, plugins='renderSetup.py',
            uiScript='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.createLightEditorWindow(restore=True)',
            closeCallback='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.lightEditorWindowClosed()')

    if restore == False:
        createPropertyEditorWindow()
    else:
        cmds.evalDeferred('import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.createPropertyEditorWindow()')

    return _lightEditorWindow


def propertyEditorWindowClosed():
    global _propertyEditorWindow
    if _propertyEditorWindow:
        _propertyEditorWindow.aboutToDelete()
        _propertyEditorWindow = None

def propertyEditorWindowChanged():
    global _propertyEditorWindow
    saveWindowState(_propertyEditorWindow, 'lightPropertyWindowState')

def createPropertyEditorWindow(restore=False):
    global _lightEditorWindow
    global _propertyEditorWindow

    if not _lightEditorWindow:
        return

    if restore:
        parent = OpenMayaUI.MQtUtil.getCurrentParent()

    if not _propertyEditorWindow:
        _propertyEditorWindow = propertyEditor.PropertyEditor(treeView=_lightEditorWindow.centralWidget.lightEditorView, parent=_lightEditorWindow.dockingFrame, observeRenderSetup=False)
        _propertyEditorWindow.setObjectName('MayaLightPropertyEditorWindow')
        _propertyEditorWindow.windowStateChanged.connect(propertyEditorWindowChanged)

    if restore:
        mixinPtr = OpenMayaUI.MQtUtil.findControl(_propertyEditorWindow.objectName())
        OpenMayaUI.MQtUtil.addWidgetToMayaLayout(long(mixinPtr), long(parent))
    else:
        size = propertyEditor.PropertyEditor.PREFERRED_SIZE
        minSize = propertyEditor.PropertyEditor.MINIMUM_SIZE
        requiredControl = _lightEditorWindow.objectName() + 'WorkspaceControl'
        _propertyEditorWindow.show(dockable=True, retain=False, area='right', width=size.width(), widthSizingProperty='preferred', minWidth=minSize.width(), height=size.height(), controls=requiredControl,
            uiScript='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.createPropertyEditorWindow(restore=True)',
            closeCallback='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.propertyEditorWindowClosed()')

    # Workaround to make the property editor display the current selected items
    # if it's closed and opened again. Otherwise by default it's opened blank,
    # and you need to toggle selection manually.
    # Long term we should do a general fix for this in the render setup PropertyEditor class,
    # since it would solve the same issue for the render setup property window.
    currentSelection = OpenMaya.MGlobal.getActiveSelectionList()
    emptySelection = OpenMaya.MSelectionList()
    OpenMaya.MGlobal.setActiveSelectionList(emptySelection)
    OpenMaya.MGlobal.setActiveSelectionList(currentSelection)


def lookThroughWindowClosed():
    global _lookThroughWindow
    if _lookThroughWindow:
        _lookThroughWindow.aboutToDelete()
        _lookThroughWindow = None

def lookThroughWindowChanged():
    global _lookThroughWindow
    saveWindowState(_lookThroughWindow, 'lookThroughWindowState')

def createLookThroughWindow(restore=False):
    global _lightEditorWindow
    global _lookThroughWindow

    if not _lightEditorWindow:
        return

    if restore:
        parent = OpenMayaUI.MQtUtil.getCurrentParent()

    if not _lookThroughWindow:
        _lookThroughWindow = LookThroughWindow()
        _lookThroughWindow.windowStateChanged.connect(lookThroughWindowChanged)

    if restore:
        mixinPtr = OpenMayaUI.MQtUtil.findControl(_lookThroughWindow.objectName())
        OpenMayaUI.MQtUtil.addWidgetToMayaLayout(long(mixinPtr), long(parent))
    else:
        requiredControl = _lightEditorWindow.objectName() + 'WorkspaceControl'
        _lookThroughWindow.show(dockable=True, retain=False, controls=requiredControl,
            uiScript='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.createLookThroughWindow(restore=True)',
            closeCallback='import maya.app.renderSetup.lightEditor.views.editorUI as ui\nui.lookThroughWindowClosed()')

    lookThroughSelectedLight()

def lookThroughSelectedLight():
    global _lightEditorWindow
    global _lookThroughWindow

    if _lightEditorWindow and _lookThroughWindow:

        lightName = None
        selected = _lightEditorWindow.centralWidget.lightEditorView.selectedIndexes()
        for sel in selected:
            item = _lightEditorWindow.centralWidget.lightEditorView.model().itemFromIndex(sel)
            if item.typeIdx() == proxy.LIGHT_ITEM_TYPE_IDX:
                lightName = item.model.getLightName()

        _lookThroughWindow.lookThroughLight(lightName)
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
