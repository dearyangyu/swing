import maya
maya.utils.loadStringResourcesForModule(__name__)

from PySide2.QtCore import Qt, QRect
from PySide2.QtGui import QPainter, QColor, QBrush, QCursor, QFontMetrics, QPen,  QIcon
from PySide2.QtWidgets import QLineEdit

import maya.api.OpenMaya as OpenMaya
import maya.cmds as cmds
from copy import deepcopy
import math

import maya.app.renderSetup.views.proxy.renderSetup as renderSetup
import maya.app.renderSetup.views.renderSetupDelegate as renderSetupDelegate
import maya.app.renderSetup.views.proxy.renderSetupRoles as renderSetupRoles
import maya.app.renderSetup.views.utils as utils
import maya.app.renderSetup.lightEditor.views.proxy as proxy
import maya.app.renderSetup.lightEditor.model.typeManager as typeMgr

class DataDelegate(object):
    def draw(self, painter, rect, data, mapped):
        painter.drawText(rect, Qt.AlignLeft | Qt.AlignVCenter, " - ")

class FloatDelegate(DataDelegate):
    def draw(self, painter, rect, data, mapped):
        # Handling of decreased precision as the number of digits increase.
        # Wasn't able to make the general format "{:.3g}" work as I wanted
        # with always showing decimal points, so ended up with this manual
        # method instead.
        magnitude = math.fabs(data)
        formatStr = "{:.3e}"
        if magnitude < 100:
            formatStr = "{:.3f}"
        elif magnitude < 1000:
            formatStr = "{:.2f}"
        elif magnitude < 10000:
            formatStr = "{:.1f}"
        elif magnitude < 100000:
            formatStr = "{:.0f}"
        painter.drawText(rect, Qt.AlignLeft | Qt.AlignVCenter, formatStr.format(data))

class IntDelegate(DataDelegate):
    def draw(self, painter, rect, data, mapped):
        text = "{:d}".format(data) if data < 100000 else "{:.3e}".format(data)
        painter.drawText(rect, Qt.AlignLeft | Qt.AlignVCenter, text)

class BoolDelegate(DataDelegate):
    def draw(self, painter, rect, data, mapped):
        text = "on" if data is True else "off"
        painter.drawText(rect, Qt.AlignLeft | Qt.AlignVCenter, text)

class ColorDelegate(DataDelegate):

    COLOR_SWATCH_WIDTH = utils.dpiScale(25)

    def draw(self, painter, rect, data, mapped):
        w = rect.width()
        ad = max(w/2 - self.COLOR_SWATCH_WIDTH, 0)
        rect2 = rect.adjusted(ad-utils.dpiScale(10), utils.dpiScale(5), -ad-utils.dpiScale(10), utils.dpiScale(-5))

        # Draw the color swatch
        if mapped:
            # Draw a cross pattern to show we have a texture mapped
            painter.fillRect(rect2, QColor(200,200,200))
            painter.fillRect(rect2, Qt.DiagCrossPattern)
        else:
            # Transform color to display space and clamp to [0,1] range
            # to make sure QT will draw it correctly
            displayColor = cmds.colorManagementConvert(toDisplaySpace = data)
            displayColor = [max(min(v, 1.0), 0.0) for v in displayColor]
            displayColorQ = QColor.fromRgbF(*displayColor)
            painter.fillRect(rect2, displayColorQ)

class LightEditorDelegate(renderSetupDelegate.RenderSetupDelegate):
    """
    This class provides customization of the appearance of items in the model.
    """

    # Constants
    LIGHT_ICON_SIZE = utils.dpiScale(20)
    LIGHT_ICON_OFFSET_X = utils.dpiScale(10)
    LIGHT_ICON_OFFSET_Y = utils.dpiScale(4)
    TEXT_LEFT_OFFSET  = utils.dpiScale(15)
    TEXT_RIGHT_OFFSET = utils.dpiScale(30)
    LIGHT_ATTR_WIDTH  = utils.dpiScale(90)

    # Set delegates per data type
    dataDelegates = {"float":FloatDelegate(), "int":IntDelegate(), "bool": BoolDelegate(), "color": ColorDelegate()}

    kTooltips = {renderSetup.SET_ENABLED_ACTION : maya.stringTable['y_delegate.kEnabledToolTip' ],
                 renderSetup.SET_ISOLATE_SELECTED_ACTION : maya.stringTable['y_delegate.kIsolateToolTip' ]}

    def __init__(self, treeView):
        super(LightEditorDelegate, self).__init__(treeView)

        self.lightTypeIcon = {}

    def _drawColorBar(self, painter, rect, item):
        rect2 = deepcopy(rect)
        rect2.setRight(rect2.left() + self.COLOR_BAR_WIDTH)
        painter.fillRect(rect2, item.data(renderSetupRoles.NODE_COLOR_BAR))

        if item.type() == proxy.LIGHT_ITEM_TYPE:
            lightType = item.model.getLightType()

            # Create the icon if it's not already cached
            if lightType not in self.lightTypeIcon:
                iconFile = typeMgr.getIcon(lightType)
                icon = utils.createIcon(iconFile)
                self.lightTypeIcon[lightType] = icon

            icon = self.lightTypeIcon[lightType]
            rect2 = deepcopy(rect)
            rect2.setLeft(rect.left() + self.LIGHT_ICON_OFFSET_X)
            rect2.setRight(rect.left() + self.LIGHT_ICON_OFFSET_X + self.LIGHT_ICON_SIZE-1)
            rect2.setTop(rect.top() + self.LIGHT_ICON_OFFSET_Y)
            rect2.setBottom(rect.bottom() - self.LIGHT_ICON_OFFSET_Y)
            pixmap = icon.pixmap(self.LIGHT_ICON_SIZE, self.LIGHT_ICON_SIZE)
            painter.drawPixmap(rect2, pixmap, pixmap.rect())

    def _drawText(self, painter, rect, item):

        oldPen = painter.pen()
        painter.setPen(QPen(item.data(Qt.TextColorRole), 1))
        painter.setFont(item.data(Qt.FontRole))
        textRect = self.getTextRect(rect, item)

        maxNameWidth = utils.dpiScale(150)
        fm = painter.fontMetrics();
        name = fm.elidedText(item.data(Qt.DisplayRole), Qt.TextElideMode.ElideRight, maxNameWidth)
        painter.drawText(textRect, Qt.AlignLeft | Qt.AlignVCenter, name)

        if item.type() == proxy.LIGHT_ITEM_TYPE:

            indent = item.depth() * self.treeView().indentation()
            textRect.setLeft(textRect.left() + utils.dpiScale(157) - indent)
            textRect.setRight(textRect.left() + self.LIGHT_ATTR_WIDTH)

            for column in range(0, len(typeMgr.getAllAttributes())):

                attrLabel, dataType = typeMgr.getAllAttributes().items()[column]
                attrValue = item.columnData(Qt.DisplayRole, column)

                if attrValue is not None and dataType in LightEditorDelegate.dataDelegates:

                    # Draw the attribute label
                    painter.setPen(QPen(item.columnData(Qt.TextColorRole, column), 1))
                    painter.drawText(textRect, Qt.AlignLeft | Qt.AlignVCenter, attrLabel[0] + ":")

                    # Draw the attribute data
                    tempRect = deepcopy(textRect)
                    tempRect.setLeft(tempRect.left() + utils.dpiScale(12))
                    painter.setPen(QPen(item.data(Qt.TextColorRole), 1))
                    LightEditorDelegate.dataDelegates[dataType].draw(painter, tempRect, attrValue, item.model.isConnected(column))

                textRect.setLeft(textRect.left() + self.LIGHT_ATTR_WIDTH)
                textRect.setRight(textRect.right() + self.LIGHT_ATTR_WIDTH)

        painter.setPen(oldPen)

    def getTextRect(self, rect, item):
        textRect = super(LightEditorDelegate, self).getTextRect(rect, item)
        textRect.setLeft(textRect.left() + self.TEXT_LEFT_OFFSET)
        textRect.setRight(textRect.right() - self.TEXT_RIGHT_OFFSET)
        return textRect

    def updateEditorGeometry(self, editor, option, index):
        """ Sets the location for the double-click editor for renaming light editor entries. """
        item = self._getItem(index)
        rect = self.getTextRect(option.rect, item)

        indent = item.depth() * self.treeView().indentation()
        leftOffset = indent + self.LEFT_NON_TEXT_OFFSET
        rect.setLeft(leftOffset)

        editor.setGeometry(rect)
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
