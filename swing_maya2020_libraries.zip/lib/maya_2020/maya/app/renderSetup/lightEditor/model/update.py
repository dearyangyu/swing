import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya

_isDirty = False
_refreshUIRequested = False

def isDirty():
    global _isDirty
    return _isDirty

def setDirty(dirty):
    global _isDirty
    _isDirty = dirty

def doUpdate():
    import maya.app.renderSetup.lightEditor.model.editor as lightEditor
    setDirty(False)
    if lightEditor.hasInstance():
        lightEditor.instance().updateIsolateState()

def requestRefreshUI():
    # Do a deferred UI refresh if not requested already.
    global _refreshUIRequested
    if not _refreshUIRequested:
        _refreshUIRequested = True
        cmds.evalDeferred("import maya.app.renderSetup.lightEditor.model.update as update; update.doRefreshUI()", lowestPriority=True)

def doRefreshUI():
    import maya.app.renderSetup.lightEditor.model.editor as lightEditor
    global _refreshUIRequested
    _refreshUIRequested = False
    if lightEditor.hasInstance():
        # Request UI update for all children
        for c in lightEditor.instance().getChildren():
            c.itemChanged()

def addChangeCallbacks(node):
    """ Add callbacks needed for keeping enabled up to date in the light editor item tree when 
    selfEnabled or isolateSelected changes on an item. We have extra requirements for this 
    in the light editor since these attributes can have overrides applied, that is why these
    callbacks are needed.

    In order to support the case where an override is applied and changes the value of 
    selfEnabled or isolateSelected we must use the addNodeDirtyPlugCallback. However
    we are not allowed to perform the update immediately from this callback since it's
    called during dirty propagation and evaluation is not finished yet. So instead we
    need to defer the update until the next time someone wants to query an enabled plug.
    The addAttributeChangedCallback is used to check when that plug is evaluated and if 
    the state is set to dirty then we perform the update. """

    def _dirtyCB(nodeObj, plug, data):
        # Only update on changes to selfEnabled and isolateSelected
        if plug.attribute() in [type(node).selfEnabled, type(node).isolateSelected]:
            setDirty(True)
            # If we are in interactive mode update the UI
            if not cmds.about(batch=True):
                requestRefreshUI()

    def _attrChangedCB(msg, plug, otherPlug, clientData):
        # If the state is set to dirty and someone is evaluating the enabled value we need to do an update.
        # We also do an update if a connection to parentNumIsolatedChildren is made or broken, since this 
        # happens when items are re-parented in the editor, which might change the enabled state as well.
        if (isDirty() and plug.attribute() == type(node).enabled and msg & OpenMaya.MNodeMessage.kAttributeEval) or \
            (plug.attribute() == type(node).layerNumIsolatedChildren and \
                (msg & OpenMaya.MNodeMessage.kConnectionMade or msg & OpenMaya.MNodeMessage.kConnectionBroken)):
            doUpdate()

    # Create the callbacks
    return [OpenMaya.MNodeMessage.addNodeDirtyPlugCallback(node.thisMObject(), _dirtyCB), \
        OpenMaya.MNodeMessage.addAttributeChangedCallback(node.thisMObject(), _attrChangedCB)]
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
