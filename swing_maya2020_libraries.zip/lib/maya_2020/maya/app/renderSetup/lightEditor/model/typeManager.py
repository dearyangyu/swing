import maya.api.OpenMaya as OpenMaya
import maya.cmds as cmds
import maya.mel as mel
import maya.app.renderSetup.common.utils as commonUtils
import maya.app.renderSetup.lightEditor.model.item as itemModel
import collections

def rebuild():

	global lightTypes
	global mayaLightTypes
	global pluginLightTypes
	global uiExcludedLightTypes
	global lightConstructionData
	global allLightAttributes
	global attributesForLightType

	# Create UI exclusion list
	uiExcludedLightTypes = ["ambientLight"]

	# Add Maya light types
	mayaLightTypes = [
		"ambientLight",
		"pointLight",
		"spotLight",
		"areaLight",
		"directionalLight",
		"volumeLight"
	]

	# Add all plugin light types. These are all other node types classified as 'light',
	# but excluding some classifications that are not real light sources.
	excludeClassifications = "light/volume:light/filter:hidden"
	lightNodeType = cmds.listNodeTypes("light", exclude=excludeClassifications)
	pluginLightTypes = [nodeType for nodeType in lightNodeType if _isPluginLight(nodeType)]

	lightTypes = []
	lightTypes.extend(mayaLightTypes)
	lightTypes.extend(pluginLightTypes)

	# Create default light attribute to show in editor
	allLightAttributes = collections.OrderedDict()
	allLightAttributes["Color"] = "color"
	allLightAttributes["Intensity"] = "float"
	allLightAttributes["Exposure"] = "float"
	allLightAttributes["Samples"] = "int"

	attributesForLightDefault = {}
	attributesForLightDefault["Color"] = "color"
	attributesForLightDefault["Intensity"] = "intensity"

	attributesForLightType = {}

	# Setup attributes for each light type
	for lightType in lightTypes:
		createCmd = ""
		icon = ""

		attributes = _getAttributesFromViewTemplate(lightType, "LEDefault")
		if attributes:
			lightTypeAttrs = {}

			for attr in attributes:
				attrName = attr["name"]
				if attrName == "LEcreateCmd":
					createCmd = attr["cb"]
				elif attrName == "LEicon":
					icon = attr["cb"]
				else:
					attrLabel = attr["label"]
					attrName  = attr["name"]
					dataType  = attr["type"]

					if len(attrLabel) and len(attrName) and len(dataType):
						# Check if this is a new label
						if attrLabel not in allLightAttributes:
							allLightAttributes[attrLabel] = dataType
							lightTypeAttrs[attrLabel] = attrName
						elif dataType is allLightAttributes[attrLabel]:
							lightTypeAttrs[attrLabel] = attrName

			attributesForLightType[lightType] = lightTypeAttrs

		else:
			attributesForLightType[lightType] = attributesForLightDefault

		lightConstructionData[lightType] = (createCmd, icon)

def _getAttributesFromViewTemplate(nodeType, viewName):
	# Returns information about the attributes specified in a view template for the given node type
	templateName = ("LE" + nodeType)
	cmd = "AEvalidatedTemplateName(\"\", \"" + templateName + "\" )"
	templateName = mel.eval(cmd)
	if templateName == "":
		return None

	numKeys = 5
	keywords = "itemName:itemLabel:itemAttrType:itemDescription:itemCallback"
	viewItems = cmds.baseView(templateName, query=True, viewName=viewName, itemList=True, itemInfo=keywords)
	numViewItems = len(viewItems)
	numAttribs = numViewItems / numKeys 

	attributes = []
	for i in range(0, numAttribs):
		items = viewItems[i*numKeys : (i+1)*numKeys]
		dataType = _getDataTypeFromTemplateType(items[2])
		attribute = {
			"name":items[0],
			"label":items[1],
			"type":dataType,
			"desc":items[3],
			"cb":items[4]
		}
		attributes.append(attribute)

	return attributes

def _getDataTypeFromTemplateType(typeName):
	global dataTypeConversionTable
	if typeName in dataTypeConversionTable:
		return dataTypeConversionTable[typeName]
	return typeName

def mayaLights():
	return mayaLightTypes

def pluginLights():
	return pluginLightTypes

def lights():
	return lightTypes

def isLight(mayaObj):
	if mayaObj.hasFn(OpenMaya.MFn.kDagNode):
		fnNode = OpenMaya.MFnDagNode(mayaObj)
		nodeType = cmds.nodeType(fnNode.fullPathName())
		return nodeType in lightTypes
	return False

def isLightEditorItem(mayaObj):
	fnNode = OpenMaya.MFnDependencyNode(mayaObj)
	userNode = fnNode.userNode()
	return isinstance(userNode, itemModel.LightItemBase) if userNode else False

def isValidLightShapeObject(mayaObj):
	try:
		if isLight(mayaObj):
			fnNode = OpenMaya.MFnDagNode(mayaObj)
			parentCount = fnNode.parentCount()
			for i in range(parentCount):
				parent = fnNode.parent(i)
				if parent.hasFn(OpenMaya.MFn.kTransform):
					return True
	except:
		pass
	return False

def findLightShapeObject(transformObj):
	try:
		fnNode = OpenMaya.MFnDagNode(transformObj)
		childCount = fnNode.childCount()
		for i in range(childCount):
			child = fnNode.child(i)
			if isLight(child):
				return child
	except:
		pass
	return None

def isValidLightTransformObject(mayaObj):
	try:
		fnNode = OpenMaya.MFnDagNode(mayaObj)
		childCount = fnNode.childCount()
		for i in range(childCount):
			child = fnNode.child(i)
			if isLight(child):
				return True
	except:
		pass
	return False

def findLightTransformObject(shapeObj):
	try:
		if isLight(shapeObj):
			fnNode = OpenMaya.MFnDagNode(shapeObj)
			parentCount = fnNode.parentCount()
			for i in range(parentCount):
				parent = fnNode.parent(i)
				if parent.hasFn(OpenMaya.MFn.kTransform):
					return parent
	except:
		pass
	return None

def findAllLightTransforms():
	result = []

	for t in lightTypes:
		lightShapeNames = cmds.ls(type=t, long=True)
		if lightShapeNames and len(lightShapeNames)>0:
			for shapeName in lightShapeNames:
				shapeObj = commonUtils.nameToNode(shapeName)
				if shapeObj:
					transformObj = findLightTransformObject(shapeObj)
					if transformObj:
						result.append(transformObj)

	return result

def getCreateCmd(lightType):
	if lightType in lightConstructionData:
		data = lightConstructionData[lightType]
		if len(data[0]) > 0:
			return data[0]
	return ""

def getIcon(lightType):
	if lightType in lightConstructionData:
		data = lightConstructionData[lightType]
		iconFile = data[1]
		if len(iconFile) > 0:
			return iconFile
	DEFAULT_LIGHT_ICON = ":/LM_ambientLight.png"
	return DEFAULT_LIGHT_ICON

def getAllAttributes():
	return allLightAttributes

def getAttributesForLightType(lightType):
	return attributesForLightType[lightType] if lightType in attributesForLightType else {}

def excludeFromUI(nodeType):
	return nodeType in uiExcludedLightTypes

def _isPluginLight(nodeType):
	return not (nodeType in mayaLightTypes)


#
# Module initialization
#

lightTypes 				= []
mayaLightTypes 			= []
pluginLightTypes 		= []
uiExcludedLightTypes 	= []
lightConstructionData 	= {}
attributesForLightType 	= {}
allLightAttributes 		= collections.OrderedDict()


# Conversion from view template data type names to our internal data types names
dataTypeConversionTable = {
	"bool"   : "bool",
	"float3" : "color",
	"float"  : "float",
	"short"  : "int",
	"long"   : "int",
	"enum"   : "int"
}

# Make sure the AE methods can be found
mel.eval("source \"showEditor.mel\"")
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
