import maya
maya.utils.loadStringResourcesForModule(__name__)

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya

import maya.app.renderSetup.model.nodeList as nodeList
import maya.app.renderSetup.model.childNode as childNode
import maya.app.renderSetup.model.utils as utils
import maya.app.renderSetup.model.typeIDs as typeIDs
import maya.app.renderSetup.model.undo as undo
import maya.app.renderSetup.model.plug as plug
import maya.app.renderSetup.lightEditor.model.typeManager as typeMgr
import maya.app.renderSetup.lightEditor.model.item as itemModel

kChildAttached = maya.stringTable['y_group.kChildAttached' ]
kChildDetached = maya.stringTable['y_group.kChildDetached' ]

class LightGroup(nodeList.ListBase, itemModel.LightItemBase):
    """  Light Editor item for groups """

    kTypeId = typeIDs.lightGroup
    kTypeName = "lightGroup"

    # Attributes

    # Connection to all items in the list.
    items = OpenMaya.MObject()

    # Connections to first and last item on the linked list.
    firstItem = OpenMaya.MObject()
    lastItem  = OpenMaya.MObject()

    @classmethod
    def creator(cls):
        return cls()

    @staticmethod
    def initializer():
        LightGroup.inheritAttributesFrom(itemModel.LightItemBase.kTypeName)

        LightGroup.items = LightGroup.initListItems()

        LightGroup.firstItem = utils.createDstMsgAttr('firstItem', 'fi')
        LightGroup.addAttribute(LightGroup.firstItem)

        LightGroup.lastItem = utils.createDstMsgAttr('lastItem', 'li')
        LightGroup.addAttribute(LightGroup.lastItem)

    def __init__(self):
        super(LightGroup, self).__init__()

    def dispose(self, deleteLight):
        # Dispose any children
        for child in self.getChildren():
            child.dispose(deleteLight)

        super(LightGroup, self).dispose(deleteLight)

    def isAbstractClass(self):
        return False

    def rename(self, newName):
        if newName != self.name():
            self.setName(newName)

    def _childAttached(self, child):
        '''Perform work to attach a child.
        The child has already been added to parent's list when this
        method is called.'''
        with undo.NotifyCtxMgr(kChildAttached % (self.name(), child.name()), self.itemChanged):
            # Once inserted, hook up the child's parentEnabled input to our
            # enabled output.  Use existing command for undo / redo purposes.
            cmds.connectAttr(self.name() + '.enabled', child.name() + '.parentEnabled')
            child._attach(self)

    def _detachChild(self, child):
        '''Perform work to detach a child.
        The child has not yet been removed from the parent's list when
        this method is called.'''
        with undo.NotifyCtxMgr(kChildDetached % (self.name(), child.name()), self.itemChanged):
            # Disconnect the child's parentEnabled input from our enabled
            # output.  Use existing command for undo / redo purposes.
            childParentEnabled = child.name() + '.parentEnabled'
            cmds.disconnectAttr(self.name() + '.enabled', childParentEnabled)

            # Child parentEnabled will retain its last value, so set it
            # to True in case the collection gets parented to the render layer.
            cmds.setAttr(childParentEnabled, 1)

            child._detach(self)

    @undo.chunk('Append to item')
    def appendChild(self, child):
        """ Add a child as the highest-priority child."""
        nodeList.append(self, child)
        self._childAttached(child)

    @undo.chunk('Attach to item')
    def attachChild(self, pos, child):
        """ Attach a child at a specific position. """
        nodeList.insert(self, pos, child)
        self._childAttached(child)

    @undo.chunk('Detach from item')
    def detachChild(self, child):
        """ Detach a child whatever its position. """
        # Must perform detach operations before removing from list,
        # otherwise parenting information is gone.
        self._detachChild(child)
        nodeList.remove(self, child)

    def getChildren(self, cls=childNode.ChildNode):
        """ Get the list of all children. 
        Optionally only the children matching the given class. """
        return list(nodeList.forwardListNodeClassGenerator(self, cls))

    # These methods implement the list requirements for the nodeList module.
    #
    def _getFrontAttr(self):
        return LightGroup.firstItem

    def _getBackAttr(self):
        return LightGroup.lastItem

    def _getListItemsAttr(self):
        return LightGroup.items

    def isAcceptableChild(self, model):
        """ Check if the model could be a child """
        return model.typeId() == typeIDs.lightItem or \
            model.typeId() == typeIDs.lightGroup
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
