import maya
maya.utils.loadStringResourcesForModule(__name__)

import maya.api.OpenMaya as OpenMaya
import maya.OpenMaya
import maya.cmds as cmds

import maya.app.renderSetup.model.renderSetup as renderSetup
from maya.app.renderSetup.lightEditor.model.item import LightItemBase
from maya.app.renderSetup.lightEditor.model.light import LightItem
from maya.app.renderSetup.lightEditor.model.group import LightGroup
from maya.app.renderSetup.lightEditor.model.editor import LightEditor

kRegisterFailed   = maya.stringTable['y_initialize.kRegisterFailed' ]
kUnregisterFailed = maya.stringTable['y_initialize.kUnregisterFailed' ]

# List of each node type and corresponding node classification.
# LightItem and LightGroup must be classified as lights in order
# for them to be overridable in lights collections.
nodeTypes  = [
    (LightItemBase, "hidden"),
    (LightItem,     "hidden:light"),
    (LightGroup,    "hidden:light"),
    (LightEditor,   "hidden")
]

invisibleNodeTypes = [
    LightItemBase,
    LightItem,
    LightGroup
]

def initialize(mplugin):
    for type, classification in nodeTypes:
        try:
            mplugin.registerNode(type.kTypeName, type.kTypeId, type.creator, type.initializer, OpenMaya.MPxNode.kDependNode, classification)
        except:
            OpenMaya.MGlobal.displayError(kRegisterFailed % type.kTypeName)

    for type in invisibleNodeTypes:
        cmds.setNodeTypeFlag(type.kTypeName, display=False)

def uninitialize(mplugin):
    for type, classification in nodeTypes:
        try:
            mplugin.deregisterNode(type.kTypeId)
        except:
            OpenMaya.MGlobal.displayError(kUnregisterFailed % type.kTypeName)
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
