import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya

import maya.app.renderSetup.model.childNode as childNode
import maya.app.renderSetup.model.enabled as computeEnabled
import maya.app.renderSetup.model.typeIDs as typeIDs
import maya.app.renderSetup.model.undo as undo
import maya.app.renderSetup.model.plug as plug
import maya.app.renderSetup.model.utils as utils
import maya.app.renderSetup.lightEditor.model.update as updateModel

class LightItemBase(childNode.TreeOrderedItem, childNode.ChildNode):
    """ Base class for light editor items  """

    kTypeId = typeIDs.lightItemBase
    kTypeName = "lightItemBase"

    # Constants
    ATTRIBUTE_INTENSITY = 0
    ATTRIBUTE_EXPOSURE  = 1
    ATTRIBUTE_COLOR     = 2

    # Attributes

    # Enabled behavior
    enabled       = OpenMaya.MObject()
    selfEnabled   = OpenMaya.MObject()
    parentEnabled = OpenMaya.MObject()

    # Isolate behavior
    isolateSelected = OpenMaya.MObject()
    numIsolatedChildren = OpenMaya.MObject()
    numIsolatedAncestors = OpenMaya.MObject()

    # Awkwardly, abstract base classes seem to need a creator method.
    @classmethod
    def creator(cls):
        return cls()

    @staticmethod
    def initializer():
        LightItemBase.inheritAttributesFrom(childNode.ChildNode.kTypeName)

        # Set up enabled attribute.
        computeEnabled.initializeAttributes(LightItemBase)

        # Add isolateSelected attribute
        LightItemBase.numIsolatedChildren = computeEnabled.createNumIsolatedChildrenAttribute()
        LightItemBase.addAttribute(LightItemBase.numIsolatedChildren)

        LightItemBase.numIsolatedAncestors = computeEnabled.createHiddenIntAttribute(
            "numIsolatedAncestors", "nia")
        LightItemBase.addAttribute(LightItemBase.numIsolatedAncestors)

        # Add isolateSelected attribute
        numAttrFn = OpenMaya.MFnNumericAttribute() 
        LightItemBase.isolateSelected = numAttrFn.create("isolateSelected", "is", OpenMaya.MFnNumericData.kBoolean, 0)
        numAttrFn.storable = True
        numAttrFn.keyable = False
        numAttrFn.readable = True
        numAttrFn.writable = True
        numAttrFn.hidden = True
        LightItemBase.addAttribute(LightItemBase.isolateSelected)

        LightItemBase.attributeAffects(LightItemBase.numIsolatedChildren, LightItemBase.enabled)
        LightItemBase.attributeAffects(LightItemBase.numIsolatedAncestors, LightItemBase.enabled)
        LightItemBase.attributeAffects(LightItemBase.isolateSelected, LightItemBase.enabled)

    def __init__(self):
        super(LightItemBase, self).__init__()
        self._enabledDirty = False
        self._callbackIds = []

    def postConstructor(self):
        # Call parent class postConstructor
        super(LightItemBase, self).postConstructor()

        self.activate()

    def activate(self):
        # Register all callbacks
        if len(self._callbackIds) == 0:
            # Listen to changes in the enabled attribute.
            self._callbackIds = computeEnabled.addChangeCallbacks(self)

            # Add callbacks for extra handling of light editor model updates
            # when enabled / isolate are overridable
            self._callbackIds += updateModel.addChangeCallbacks(self)

    def deactivate(self):
        # Remove all callbacks that have been registered
        OpenMaya.MMessage.removeCallbacks(self._callbackIds)
        self._callbackIds = []

    def dispose(self, deleteLight):
        self.deactivate()

        # Remove the DG node if it's not removed already
        if len(cmds.ls(self.name())) > 0:
            cmds.delete(self.name())

    def isAbstractClass(self):
        return True

    def typeId(self):
        return self.kTypeId

    def typeName(self):
        return self.kTypeName

    def _getInputAttr(self, attr, dataBlock=None):
        return dataBlock.inputValue(attr) if dataBlock else OpenMaya.MPlug(self.thisMObject(), attr)

    def _getEnabledPlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItemBase.enabled)

    def _getSelfEnabledPlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItemBase.selfEnabled)

    def _getIsolatePlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItemBase.isolateSelected)

    def hasIsolatedAncestors(self, dataBlock=None):
        return self._getInputAttr(self.numIsolatedAncestors, dataBlock).asInt() > 0

    def hasIsolatedChildren(self, dataBlock=None):
        return self._getInputAttr(self.numIsolatedChildren, dataBlock).asInt() > 0

    def enabledChanged(self):
        self.itemChanged()
        for c in self.getChildren():
            c.itemChanged()

    def isEnabled(self):
        return self._getEnabledPlug().asBool()

    def isSelfEnabled(self, dataBlock=None):
        return self._getInputAttr(self.selfEnabled, dataBlock).asBool()

    def setSelfEnabled(self, value):
        if value != self.isSelfEnabled():
            with undo.NotifyCtxMgr("Set Item Enabled", self.itemChanged):
                cmds.setAttr(self._getSelfEnabledPlug().name(), value)

    def isIsolateSelected(self, dataBlock=None):
        return self._getInputAttr(self.isolateSelected, dataBlock).asBool()

    def setIsolateSelected(self, value):
        if value != self.isIsolateSelected():
            with undo.NotifyCtxMgr("Set Item Isolated", self.itemChanged):
                cmds.setAttr(self._getIsolatePlug().name(), value)

    def getLayerNumIsolatedChildren(self):
        return OpenMaya.MPlug(
            self.thisMObject(), LightItemBase.layerNumIsolatedChildren).asInt()

    def _getNumIsolatedChildrenPlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItemBase.numIsolatedChildren)

    def getNumIsolatedChildren(self, includeSelf=False):
        nic = self._getNumIsolatedChildrenPlug().asInt()
        if includeSelf and self.isIsolateSelected():
            nic += 1
        return nic

    def _getNumIsolatedAncestorsPlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItemBase.numIsolatedAncestors)

    def getNumIsolatedAncestors(self):
        return self._getNumIsolatedAncestorsPlug().asInt()

    def updateIsolateState(self, numIsolatedAncestors = 0):
        """Update the isolate state in the item hierarchy.

        Pushing the number of isolated ancestors down the tree,
        and pulling the number of isolated children back up."""

        self._getNumIsolatedAncestorsPlug().setInt(numIsolatedAncestors)

        numIsolatedChildren = 0
        for child in self.getChildren():
            numIsolatedChildren += int(child.isIsolateSelected())
            numIsolatedChildren += child.updateIsolateState(numIsolatedAncestors + int(self.isIsolateSelected()))

        self._getNumIsolatedChildrenPlug().setInt(numIsolatedChildren)

        return numIsolatedChildren

    def _attach(self, parent):
        """Attach this item."""
        if parent:
            # Use existing command for undo / redo purposes.
            cmds.connectAttr(parent.name() + '.numIsolatedChildren',
                             self.name() + '.parentNumIsolatedChildren')

    def _detach(self, parent):
        """Detach this item."""
        if parent:
            # Use existing command for undo / redo purposes.
            cmds.disconnectAttr(parent.name() + '.numIsolatedChildren',
                                self.name() + '.parentNumIsolatedChildren')

    def detachFromParent(self):
        parent = self.parent()
        if parent:
            parent.detachChild(self)

    def getChildren(self, cls=childNode.ChildNode):
        return list([])

    def isAcceptableChild(self, model):
        """ Check if the model could be a child """
        return False

    def compute(self, plug, dataBlock):
        if plug == self.enabled:
            # We are enabled if:
            #
            # o The normal enabled computation is true (self enabled is true AND
            #   parent enabled is true).
            #
            # AND
            #
            # o No node is isolated OR
            # o This node is isolated OR
            # o This node has isolate selected children OR
            # o This node has isolate selected ancestors.
            #
            value = computeEnabled.computeEnabled(self, dataBlock) and \
                (dataBlock.inputValue(self.layerNumIsolatedChildren).asInt()==0 or \
                self.isIsolateSelected(dataBlock) or \
                self.hasIsolatedAncestors(dataBlock) or \
                self.hasIsolatedChildren(dataBlock))
            computeEnabled.setEnabledOutput(self, dataBlock, value)

def getLightItemName(lightShapeObj):
    fn = OpenMaya.MFnDependencyNode(lightShapeObj)
    return fn.name() + '__LEItem'

@undo.chunk("Create light editor item")
def createItem(name, nodeType):
    """Create an item with type given by the argument type ID.

    Returns the MPxNode object corresponding to the created item node.
    A RuntimeError is raised in case of error.

    This function is undoable."""

    if isinstance(nodeType, basestring):
        typeName = nodeType
    else:
        typeName = cmds.objectType(typeFromTag=nodeType.id())

    # Using existing command for undo / redo purposes, even if it requires
    # a name-based lookup to return the user node, since item node
    # creation is not performance-critical.  If the name flag is specified,
    # it cannot be an empty string.
    returnName = cmds.createNode(typeName, name=name, skipSelect=True) if name \
                 else cmds.createNode(typeName, skipSelect=True)

    return utils.nameToUserNode(returnName)

@undo.chunk('Delete light editor item')
def deleteItem(item, deleteLight=True):
    """Remove the argument item from the scene."""

    # Inform our parent (if any) of upcoming delete.
    item.detachFromParent()

    # Do any required finalization
    item.dispose(deleteLight)
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
