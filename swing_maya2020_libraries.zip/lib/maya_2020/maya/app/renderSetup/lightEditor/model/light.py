import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya

import maya.app.renderSetup.model.utils as utils
import maya.app.renderSetup.model.typeIDs as typeIDs
import maya.app.renderSetup.model.applyOverride as applyOverride
import maya.app.renderSetup.model.plug as plug
import maya.app.renderSetup.common.guard as guard

import maya.app.renderSetup.lightEditor.model.editor as editorModel
import maya.app.renderSetup.lightEditor.model.typeManager as typeMgr
import maya.app.renderSetup.lightEditor.model.item as itemModel
import maya.app.renderSetup.lightEditor.model.update as update

class LightItem(itemModel.LightItemBase):
    """  Light editor item for light sources """

    kTypeId = typeIDs.lightItem
    kTypeName = "lightItem"

    # Attributes
    light = OpenMaya.MObject()

    @classmethod
    def creator(cls):
        return cls()

    @staticmethod
    def initializer():
        LightItem.inheritAttributesFrom(itemModel.LightItemBase.kTypeName)

        LightItem.light = utils.createDstMsgAttr('light', 'lgt')
        LightItem.addAttribute(LightItem.light)

    def __init__(self):
        super(LightItem, self).__init__()
        self._trackVisibility = True
        self._lightCallbackIds = []

        # Some changes might need a UI rebuild,
        # to update the UI properly. If so set this
        # flag to True during the call to itemChanged()
        self.needUIRebuildWhenChanged = False

    def dispose(self, deleteLight):
        # Remove all callbacks that have been registered
        OpenMaya.MMessage.removeCallbacks(self._lightCallbackIds)
        self._lightCallbackIds = []

        # Remove the light node if requested
        if deleteLight:
            xform = self.getLightTransform()
            if xform:
                cmds.delete(OpenMaya.MFnDagNode(xform).fullPathName())

        super(LightItem, self).dispose(deleteLight)

    def isAbstractClass(self):
        return False

    def _onLightShapePreRemovalCB(self, obj, clientData):
        if editorModel.hasInstance():
            # Find the corresponding item and delete it
            item = editorModel.instance().findEditorItem(obj)
            if item:
                itemModel.deleteItem(item, deleteLight=False)

    def _onLightNameChangedCB(self, obj, oldName, clientData):
        # Rename the item according to the new light name
        newName = itemModel.getLightItemName(obj)
        dgMod = OpenMaya.MDGModifier()
        dgMod.renameNode(self.thisMObject(), newName)
        dgMod.doIt()
        self.itemChanged()

    def _onLightAttrChangedCB(self, msg, plg, otherPlug, clientData):
        if self._trackVisibility and plg.partialName(useLongNames=True) == 'visibility':
            self.setSelfEnabled(plg.asBool())
        # For connection changes we need to requild the UI,
        # in case this was a connection to a relative override.
        if msg & OpenMaya.MNodeMessage.kConnectionMade or msg & OpenMaya.MNodeMessage.kConnectionBroken:
            with guard.MemberGuardCtx(self, 'needUIRebuildWhenChanged', True):
                self.itemChanged()
        else:
            self.itemChanged()

    def _getLightPlug(self):
        return OpenMaya.MPlug(self.thisMObject(), LightItem.light)

    def _onDirtyCB(self, nodeObj, plug, data):
        # Needed to update the treeview when override values are changed in render setup
        update.requestRefreshUI()

    def registerCallbacks(self, lightShapeObj):
        # Add the callbacks if they have not been added for this light shape already
        if len(self._lightCallbackIds) == 0 or lightShapeObj != self.getLightShape():
            OpenMaya.MMessage.removeCallbacks(self._lightCallbackIds)
            self._lightCallbackIds = []
            self._lightCallbackIds.append(OpenMaya.MNodeMessage.addNodePreRemovalCallback(lightShapeObj, self._onLightShapePreRemovalCB))
            self._lightCallbackIds.append(OpenMaya.MNodeMessage.addNameChangedCallback(lightShapeObj, self._onLightNameChangedCB))
            self._lightCallbackIds.append(OpenMaya.MNodeMessage.addAttributeChangedCallback(lightShapeObj, self._onLightAttrChangedCB))
            self._lightCallbackIds.append(OpenMaya.MNodeMessage.addNodeDirtyPlugCallback(lightShapeObj, self._onDirtyCB))

    def unregisterCallbacks(self):
        OpenMaya.MMessage.removeCallbacks(self._lightCallbackIds)
        self._lightCallbackIds = []

    def setLightShape(self, lightShapeObj):
        plg = self._getLightPlug()
        if lightShapeObj is None:
            # Disconnect an existing light shape.
            # Make sure there is a connection first, to handle the case of 
            # clearing out and already cleared light item.
            if plg.isDestination:
                cmds.disconnectAttr(plg.source().name(), plg.name())
        else:
            # Connect the light shape
            fn = OpenMaya.MFnDagNode(lightShapeObj)
            attr1 = fn.fullPathName() + '.message'
            attr2 = plg.name()
            if not cmds.isConnected(attr1, attr2):
                cmds.connectAttr(attr1, attr2, force=True)

            # Add callbacks on the light shape
            self.registerCallbacks(lightShapeObj)

    def getLightShape(self):
        plg = self._getLightPlug()
        src = plg.source()
        return None if src.isNull else src.node()

    def getLightTransform(self):
        shape = self.getLightShape()
        return typeMgr.findLightTransformObject(shape)

    def getLightName(self, fullPath = False):
        shape = self.getLightShape()
        if shape:
            return OpenMaya.MFnDagNode(shape).fullPathName() if fullPath else OpenMaya.MFnDagNode(shape).name()
        return None

    def getLightType(self):
        shape = self.getLightShape()
        return cmds.nodeType(OpenMaya.MFnDagNode(shape).fullPathName()) if shape else 'unknown'

    def rename(self, newName):
        oldName = self.getLightName()
        # Get light name will return None if no light source is 
        # connected to this item. So make sure we have a valid
        # oldName before trying to change it.
        if oldName and newName != oldName:
            cmds.rename(oldName, newName)

    def isAcceptableChild(self, model):
        """ Check if the model could be a child """
        return False

    def getAttrName(self, index):
        lightType = self.getLightType()
        if lightType and index < len(typeMgr.getAllAttributes().items()):
            attrLabel, dataType = typeMgr.getAllAttributes().items()[index]
            attributes = typeMgr.getAttributesForLightType(lightType)
            if attrLabel in attributes:
                return attributes[attrLabel]
        return None

    def getAttrPlug(self, index):
        attrName = self.getAttrName(index)
        if attrName:
            shape = self.getLightShape()
            return plug.findPlug(shape, attrName)
        return None

    def getAttrValue(self, index):
        plg = self.getAttrPlug(index)
        return plg.uiUnitValue if plg else None

    def isConnected(self, index):
        plg = self.getAttrPlug(index)
        if plg is None or not plg.plug.isDestination:
            return False

        # Check if the connection is an override
        source = plg.plug.source()
        fn = OpenMaya.MFnDependencyNode(source.node())
        return not isinstance(fn.userNode(), applyOverride.ApplyOverride)

    def compute(self, mplug, dataBlock):
        if mplug == self.enabled:
            # Do the computation
            super(LightItem, self).compute(mplug, dataBlock)

            # Propagate the value to the light source
            shape = self.getLightShape()
            if shape:
                # Disable tracking while setting the value to avoid circular dependency
                with guard.MemberGuardCtx(self, '_trackVisibility', False):
                    plg = plug.findPlug(shape, 'visibility')
                    plg.value = self.isEnabled()
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
