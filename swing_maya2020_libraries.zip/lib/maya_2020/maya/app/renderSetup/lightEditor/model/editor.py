import maya
maya.utils.loadStringResourcesForModule(__name__)

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya

import maya.app.renderSetup.model.utils as utils
import maya.app.renderSetup.model.typeIDs as typeIDs
import maya.app.renderSetup.model.undo as undo
import maya.app.renderSetup.model.namespace as namespace
import maya.app.renderSetup.model.plug as plug
import maya.app.renderSetup.common.utils as commonUtils
import maya.app.renderSetup.lightEditor.model.typeManager as typeMgr
import maya.app.renderSetup.lightEditor.model.item as itemModel
from maya.app.renderSetup.lightEditor.model.group import LightGroup

# Name of the singleton node, and its type. 
# The light editor singleton must be in the root namespace.
_LIGHT_EDITOR_NODE_TYPE = 'lightEditor'
_LIGHT_EDITOR_NODE_NAME = ':' + _LIGHT_EDITOR_NODE_TYPE

kLightEditorNodeNameMismatch = maya.stringTable['y_editor.kLightEditorNodeNameMismatch' ]

def hasInstance():
    """ Return true if the light editor node exists """
    return commonUtils.nameToNode(_LIGHT_EDITOR_NODE_NAME) is not None

@namespace.root
def _createInstance():
    fn = OpenMaya.MFnDependencyNode()
    lightEditorObj = fn.create(LightEditor.kTypeId, _LIGHT_EDITOR_NODE_NAME)

    if ':' + fn.name() != _LIGHT_EDITOR_NODE_NAME:
        cmds.delete(fn.name())
        exceptionInfo = (LightEditor.kTypeName, _LIGHT_EDITOR_NODE_NAME)
        raise ValueError(kLightEditorNodeNameMismatch % exceptionInfo)

    return lightEditorObj

def instance():
    """Return the light editor singleton node, creating it if required."""
    lightEditorObj = commonUtils.nameToNode(_LIGHT_EDITOR_NODE_NAME)
    if not lightEditorObj:
        # No lightEditor node, create one
        # Creation of the light editor node singleton must not affect
        # undo stack, disable it for the creation only
        swf = cmds.undoInfo(query=True, stateWithoutFlush=True)
        try:
            cmds.undoInfo(stateWithoutFlush=False)
            lightEditorObj = _createInstance()
        finally:
            cmds.undoInfo(stateWithoutFlush=swf)

    fn = OpenMaya.MFnDependencyNode(lightEditorObj)
    # If the lightEditor node isn't the proper type, blow up.
    if fn.typeId != LightEditor.kTypeId:
        exceptionInfo = (_LIGHT_EDITOR_NODE_NAME, LightEditor.kTypeName)
        raise TypeError(kLightEditorNodeNameMismatch % exceptionInfo)

    return fn.userNode()


class LightEditor(LightGroup):
    """Singleton group item that is the root of the light editor items.

    The light editor node is a singleton: at most one can exist in a scene.
    It is not implemented as a default node, and therefore is not created
    on file new, but rather created on demand."""

    kTypeId = typeIDs.lightEditor
    kTypeName = _LIGHT_EDITOR_NODE_TYPE

    @staticmethod
    def creator():
        return LightEditor()

    @staticmethod
    def initializer():
        LightEditor.inheritAttributesFrom(LightGroup.kTypeName)

    def __init__(self):
        super(LightEditor, self).__init__()

    def postConstructor(self):
        # Call parent class postConstructor
        super(LightEditor, self).postConstructor()

    def isAbstractClass(self):
        return False

    def parent(self):
        """Returns None, as the render setup node is the root of the hierarchy."""
        return None

    def ancestors(self):
        """Returns a single-element deque with the render setup node itself."""
        return deque([self])

    def findEditorItem(self, obj):
        # Find the editor item for a Maya object
        if typeMgr.isValidLightTransformObject(obj):
            obj = typeMgr.findLightShapeObject(obj)
        if obj:
            plg = plug.findPlug(obj, "message")
            dst = utils.plugDst(plg.plug)
            for d in dst if dst else []:
                fn = OpenMaya.MFnDependencyNode(d.node())
                if fn.typeId == typeIDs.lightItem:
                    return fn.userNode()
        return None

    @undo.chunk('Create and append a light item')
    def createLightItem(self, lightShapeObj, parent=None):
        """ Create and append a new light list item """
        name = itemModel.getLightItemName(lightShapeObj)
        item = itemModel.createItem(name, 'lightItem')
        item.setLightShape(lightShapeObj)
        if parent:
            parent.appendChild(item)
        else:
            self.appendChild(item)
        return item

    @undo.chunk('Create and append a group item')
    def createGroupItem(self, parent=None):
        """ Create and append a new group list item """
        item = itemModel.createItem('lightGroup1', 'lightGroup')
        if parent:
            parent.appendChild(item)
        else:
            self.appendChild(item)
        return item

    def rebuildScene(self):
        # Rebuild the type manager in case a new plugin 
        # with new light types were loaded
        typeMgr.rebuild()

        # Find any imported light editor nodes and transfer its
        # children to this light editor node
        lightEditorNames = cmds.ls(type=_LIGHT_EDITOR_NODE_TYPE, long=True)
        for lightEditorName in lightEditorNames if lightEditorNames else []:
            lightEditor = utils.nameToUserNode(lightEditorName)

            # Ignore our own instance and also ignore any referenced nodes
            # since we don't support mixing in referenced light editor items.
            # For referenced lights new editor items will be created instead below.
            if lightEditor != self and not OpenMaya.MFnDependencyNode(lightEditor.thisMObject()).isFromReferencedFile:
                # Detach the children from the other editor and add it to this editor.
                children = lightEditor.getChildren()
                for child in children:
                    lightEditor.detachChild(child)
                for child in children:
                    self.appendChild(child)

                # Delete the other editor node
                cmds.delete(lightEditor.name())

        # Iterate all lights in the scene and make sure they have
        # a light editor item assigned.
        lightTypes = typeMgr.lights()
        lightShapeNames = cmds.ls(type=lightTypes, long=True)
        if lightShapeNames and len(lightShapeNames)>0:
            for shapeName in lightShapeNames:
                shape = commonUtils.nameToNode(shapeName)
                lightItem = self.findEditorItem(shape)

                # We don't support light editor items from referenced files
                # so ignore such items and create new once below instead.
                if lightItem and OpenMaya.MFnDependencyNode(lightItem.thisMObject()).isFromReferencedFile:
                    # Disconnect the light shape from this referenced item.
                    lightItem.setLightShape(None)
                    lightItem = None

                if lightItem:
                    # A valid light item exists already.
                    # Make sure the callbacks are setup for this light shape.
                    lightItem.registerCallbacks(shape)
                else:
                    # No valid light item exists so create one.
                    self.createLightItem(shape)

        # Make sure isolate state is up to date
        self.updateIsolateState()
# ===========================================================================
# Copyright 2017 Autodesk, Inc. All rights reserved.
#
# Use of this software is subject to the terms of the Autodesk license
# agreement provided at the time of installation or download, or which
# otherwise accompanies this software in either electronic or hard copy form.
# ===========================================================================
