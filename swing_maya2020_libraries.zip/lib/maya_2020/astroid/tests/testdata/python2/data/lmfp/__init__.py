# force a "direct" python import
from . import foo
